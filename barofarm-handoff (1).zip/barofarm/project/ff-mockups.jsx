// ff-mockups.jsx — Fresh Field detailed UI/UX mockups for development handoff
// Each screen uses iOS frame + FF design tokens.

const FFMOCK_P = paletteFor(FF, false);
const FFMOCK_F = FF.fonts;
const FFMOCK_R = FF.radius;

// ── shared atoms ────────────────────────────────────────────────────────
function MPulse({ color = '#fff', size = 6 }) {
  return (
    <span style={{ position: 'relative', width: size, height: size, display: 'inline-block' }}>
      <span style={{ position: 'absolute', inset: 0, borderRadius: '50%', background: color,
        animation: 'mp-pulse 1.4s ease-out infinite', opacity: 0.6 }} />
      <span style={{ position: 'absolute', inset: 0, borderRadius: '50%', background: color }} />
      <style>{`@keyframes mp-pulse{0%{transform:scale(1);opacity:.6}100%{transform:scale(2.4);opacity:0}}`}</style>
    </span>);

}

function ImagePH({ ratio = '1/1', label, p = FFMOCK_P, radius = FFMOCK_R, style = {} }) {
  return (
    <div style={{
      aspectRatio: ratio,
      background: `repeating-linear-gradient(135deg, ${p.surfaceAlt}, ${p.surfaceAlt} 6px, ${p.bgAlt} 6px, ${p.bgAlt} 12px)`,
      borderRadius: radius,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      ...style
    }}>
      {label && <div style={{
        background: p.bg, color: p.inkMute, fontFamily: FFMOCK_F.mono, fontSize: 9,
        padding: '2px 6px', borderRadius: 3
      }}>{label}</div>}
    </div>);

}

function CountdownChip({ time, p = FFMOCK_P }) {
  return (
    <span style={{
      background: 'rgba(0,0,0,.6)', color: '#fff',
      padding: '3px 8px', borderRadius: 4,
      fontFamily: FFMOCK_F.mono, fontSize: 10, fontWeight: 500
    }}>{time}</span>);

}

function LiveBadge({ p = FFMOCK_P }) {
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 5,
      background: p.live, color: '#fff',
      padding: '3px 8px', borderRadius: 3,
      fontFamily: FFMOCK_F.mono, fontSize: 10, fontWeight: 700, letterSpacing: '0.08em'
    }}>
      <MPulse color="#fff" /> LIVE
    </span>);

}

function CatBadge({ cat, p = FFMOCK_P, ghost = false }) {
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 4,
      background: ghost ? 'transparent' : cat.hue, color: ghost ? cat.hue : cat.ink,
      border: ghost ? `1px solid ${cat.hue}` : 'none',
      padding: '3px 8px', borderRadius: 3,
      fontSize: 10, fontWeight: 600
    }}>
      <span>{cat.icon}</span>{cat.ko}
    </span>);

}

// ── 1. Home ─────────────────────────────────────────────────────────────
function MockHome() {
  const p = FFMOCK_P,f = FFMOCK_F;
  const liveItems = [
  { cat: CATEGORIES[0], title: '성주 꿀참외 5kg · 박스 단위', farm: '성주 김영농 농가', price: '24,800', unit: '/박스', bidders: 28, time: '02:14', img: 'chamoe.jpg', cert: 'GAP' },
  { cat: CATEGORIES[1], title: '평창 유기농 감자 10kg', farm: '평창 산골농원', price: '18,200', unit: '/10kg', bidders: 14, time: '05:42', img: 'potato.jpg', cert: '유기농' }];

  const upcoming = [
  { cat: CATEGORIES[3], title: '횡성 한우 1++ 등심 1kg', start: '오늘 오후 8시', notify: 142 },
  { cat: CATEGORIES[4], title: '완도 활전복 大 20미', start: '내일 오전 11시', notify: 64 },
  { cat: CATEGORIES[2], title: '이천 햅쌀 20kg (2024)', start: '내일 오후 3시', notify: 38 }];


  return (
    <div style={{ background: p.bg, minHeight: '100%', paddingBottom: 80 }}>
      {/* Header */}
      <div style={{ padding: '62px 20px 14px', display: 'flex', alignItems: 'center', gap: 10 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, flex: 1 }}>
          <span style={{ fontFamily: f.display, fontSize: 22, fontWeight: 800,
            letterSpacing: '-0.03em', color: p.ink }}>바로팜</span>
          <span style={{ fontSize: 10, fontFamily: f.mono, color: p.inkMute, letterSpacing: '0.06em',
            padding: '2px 6px', border: `1px solid ${p.line}`, borderRadius: 3 }}>NH</span>
        </div>
        <div style={{ width: 36, height: 36, borderRadius: 18, background: p.surface,
          border: `1px solid ${p.line}`, display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 14, color: p.ink }}>♡</div>
        <div style={{ width: 36, height: 36, borderRadius: 18, background: p.surface,
          border: `1px solid ${p.line}`, display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 14, color: p.ink }}>◔</div>
      </div>

      {/* Search */}
      <div style={{ padding: '0 20px 16px' }}>
        <div style={{ height: 44, background: p.surface, borderRadius: 22,
          border: `1px solid ${p.line}`, display: 'flex', alignItems: 'center', padding: '0 16px', gap: 10 }}>
          <span style={{ color: p.inkMute, fontSize: 14 }}>⌕</span>
          <span style={{ fontSize: 14, color: p.inkMute }}>품목, 산지, 농가 검색</span>
        </div>
      </div>

      {/* Category pills horizontal scroll */}
      <div style={{ padding: '0 0 18px', overflowX: 'auto' }}>
        <div style={{ display: 'flex', gap: 6, padding: '0 20px', whiteSpace: 'nowrap' }}>
          <div style={{ padding: '7px 14px', background: p.ink, color: p.bg, borderRadius: 999,
            fontSize: 12, fontWeight: 600 }}>전체</div>
          {CATEGORIES.map((c) =>
          <div key={c.id} style={{ padding: '7px 14px', background: p.surface,
            border: `1px solid ${p.line}`, borderRadius: 999, fontSize: 12, fontWeight: 500,
            color: p.ink, display: 'inline-flex', gap: 5, alignItems: 'center' }}>
              <span style={{ color: c.hue }}>{c.icon}</span>{c.ko}
            </div>
          )}
        </div>
      </div>

      {/* Live now section */}
      <div style={{ padding: '0 20px 8px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, minWidth: 0 }}>
          <MPulse color={p.live} size={7} />
          <div style={{ fontSize: 18, fontWeight: 700, color: p.ink, letterSpacing: '-0.01em', whiteSpace: 'nowrap' }}>지금 라이브</div>
        </div>
        <div style={{ fontSize: 12, color: p.inkMute, whiteSpace: 'nowrap', flexShrink: 0 }}>전체보기 →</div>
      </div>

      <div style={{ padding: '8px 20px 20px', display: 'flex', flexDirection: 'column', gap: 14 }}>
        {liveItems.map((it, i) =>
        <div key={i} style={{ background: p.surface, borderRadius: FFMOCK_R * 1.5,
          border: `1px solid ${p.line}`, overflow: 'hidden' }}>
            <div style={{ position: 'relative' }}>
              <ImagePH ratio="16/10" label={it.img} p={p} radius={0} />
              <div style={{ position: 'absolute', top: 10, left: 10, display: 'flex', gap: 5, flexWrap: 'wrap' }}>
                <LiveBadge p={p} />
                <CatBadge cat={it.cat} p={p} />
                <span style={{ background: '#fff', color: p.success, padding: '3px 7px', borderRadius: 3,
                fontSize: 10, fontWeight: 700, border: `1px solid ${p.success}` }}>{it.cert}</span>
              </div>
              <div style={{ position: 'absolute', top: 10, right: 10 }}>
                <CountdownChip time={it.time} p={p} />
              </div>
            </div>
            <div style={{ padding: 14 }}>
              <div style={{ fontSize: 11, color: p.inkMute, fontFamily: f.mono, marginBottom: 4 }}>
                {it.farm} · 오늘 새벽 수확
              </div>
              <div style={{ fontSize: 14, fontWeight: 600, color: p.ink, lineHeight: 1.35 }}>
                {it.title}
              </div>
              <div style={{ marginTop: 10, display: 'flex', alignItems: 'baseline', justifyContent: 'space-between' }}>
                <div>
                  <div style={{ fontFamily: f.mono, fontSize: 9, color: p.inkMute, letterSpacing: '0.06em' }}>
                    현재 낙찰가
                  </div>
                  <div style={{ fontSize: 22, fontWeight: 700, color: p.ink, letterSpacing: '-0.02em' }}>
                    ₩{it.price}<span style={{ fontSize: 13, fontWeight: 500, color: p.inkSoft }}>{it.unit}</span>
                  </div>
                </div>
                <div style={{ textAlign: 'right', fontSize: 11, color: p.inkSoft }}>
                  입찰 {it.bidders}회
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Upcoming */}
      <div style={{ padding: '4px 20px 8px' }}>
        <div style={{ fontSize: 18, fontWeight: 700, color: p.ink, letterSpacing: '-0.01em' }}>
          예고된 옥션
        </div>
      </div>
      <div style={{ padding: '8px 20px 20px', display: 'flex', flexDirection: 'column', gap: 8 }}>
        {upcoming.map((it, i) =>
        <div key={i} style={{ background: p.surface, borderRadius: FFMOCK_R,
          border: `1px solid ${p.line}`, padding: 12, display: 'flex', alignItems: 'center', gap: 12 }}>
            <div style={{ width: 56, height: 56, borderRadius: FFMOCK_R / 1.4,
            background: it.cat.hue + '22',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            color: it.cat.hue, fontSize: 20 }}>{it.cat.icon}</div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                <CatBadge cat={it.cat} p={p} ghost />
              </div>
              <div style={{ fontSize: 13, fontWeight: 600, color: p.ink, marginTop: 4,
              whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                {it.title}
              </div>
              <div style={{ fontFamily: f.mono, fontSize: 10, color: p.inkMute, marginTop: 2 }}>
                {it.start} · 알림 {it.notify}
              </div>
            </div>
            <button style={{ background: 'transparent', border: `1px solid ${p.accent}`,
            color: p.accent, padding: '6px 10px', borderRadius: 999,
            fontSize: 11, fontWeight: 600 }}>알림</button>
          </div>
        )}
      </div>

      <TabBar active="home" p={p} />
    </div>);

}

function TabBar({ active = 'home', p = FFMOCK_P }) {
  const tabs = [
  { id: 'home', label: '홈', icon: '⌂' },
  { id: 'live', label: '라이브', icon: '◉' },
  { id: 'wish', label: '관심', icon: '♡' },
  { id: 'me', label: '마이', icon: '○' }];

  return (
    <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0,
      background: p.surface, borderTop: `1px solid ${p.line}`,
      padding: '8px 0 30px', display: 'flex', justifyContent: 'space-around' }}>
      {tabs.map((t) =>
      <div key={t.id} style={{ display: 'flex', flexDirection: 'column',
        alignItems: 'center', gap: 2,
        color: t.id === active ? p.accent : p.inkMute }}>
          <div style={{ fontSize: 18 }}>{t.icon}</div>
          <div style={{ fontSize: 10, fontWeight: t.id === active ? 700 : 500 }}>{t.label}</div>
        </div>
      )}
    </div>);

}

// ── 2. Category browse ─────────────────────────────────────────────────
function MockCategory() {
  const p = FFMOCK_P,f = FFMOCK_F;
  const cat = CATEGORIES[0]; // 과일
  const items = Array.from({ length: 6 }, (_, i) => ({
    title: ['성주 꿀참외 5kg', '나주 햇배 10kg', '제주 한라봉 5kg', '청송 사과 부사 10kg', '상주 곶감 1kg', '문경 사과 시나노골드 5kg'][i],
    farm: ['성주 김영농', '나주 배명가', '제주 감귤원', '청송 햇살농원', '상주 곶감마을', '문경 햇사과'][i],
    price: ['24,800', '42,000', '38,500', '55,000', '78,000', '32,400'][i],
    unit: ['/박스', '/10kg', '/5kg', '/10kg', '/kg', '/5kg'][i],
    bidders: [28, 14, 33, 7, 41, 2][i],
    live: i < 2,
    time: ['02:14', '05:42', '12h', '3d', '1d', '6h'][i]
  }));
  return (
    <div style={{ background: p.bg, minHeight: '100%', paddingBottom: 80 }}>
      <div style={{
        background: cat.hue,
        padding: '62px 20px 24px',
        color: cat.ink
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 18 }}>
          <span style={{ fontSize: 18 }}>‹</span>
          <span style={{ fontSize: 14, opacity: 0.9 }}>홈</span>
        </div>
        <div style={{ fontSize: 32, fontWeight: 800, letterSpacing: '-0.03em' }}>
          {cat.ko}
        </div>
        <div style={{ marginTop: 4, fontSize: 13, opacity: 0.85, fontFamily: f.mono }}>
          제철 산지 · 라이브 2 · 예고 18 · 마감 142
        </div>
      </div>

      <div style={{ padding: '14px 20px 8px', display: 'flex', alignItems: 'center',
        justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', gap: 6 }}>
          {['전체', '라이브', '예고', '마감임박'].map((s, i) =>
          <div key={s} style={{ padding: '6px 12px',
            background: i === 0 ? p.ink : p.surface,
            color: i === 0 ? p.bg : p.ink,
            border: i === 0 ? 'none' : `1px solid ${p.line}`,
            borderRadius: 999, fontSize: 12, fontWeight: i === 0 ? 600 : 500 }}>
              {s}
            </div>
          )}
        </div>
        <div style={{ fontSize: 12, color: p.inkMute }}>마감 ↓</div>
      </div>

      <div style={{ padding: '12px 20px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
        {items.map((it, i) =>
        <div key={i} style={{ background: p.surface, borderRadius: FFMOCK_R,
          border: `1px solid ${p.line}`, overflow: 'hidden' }}>
            <div style={{ position: 'relative' }}>
              <ImagePH ratio="1/1" p={p} radius={0} />
              {it.live ?
            <div style={{ position: 'absolute', top: 6, left: 6 }}><LiveBadge p={p} /></div> :

            <div style={{ position: 'absolute', top: 6, left: 6, background: 'rgba(0,0,0,.5)',
              color: '#fff', padding: '2px 6px', borderRadius: 3,
              fontFamily: f.mono, fontSize: 9 }}>{it.time}</div>
            }
            </div>
            <div style={{ padding: 10 }}>
              <div style={{ fontSize: 10, color: p.inkMute, fontFamily: f.mono, marginBottom: 3 }}>
                {it.farm}
              </div>
              <div style={{ fontSize: 12, fontWeight: 600, color: p.ink, lineHeight: 1.3,
              height: 32, overflow: 'hidden' }}>{it.title}</div>
              <div style={{ marginTop: 6, fontSize: 14, fontWeight: 700, color: p.ink, letterSpacing: '-0.02em' }}>
                ₩{it.price}<span style={{ fontSize: 10, fontWeight: 500, color: p.inkSoft }}>{it.unit}</span>
              </div>
              <div style={{ fontFamily: f.mono, fontSize: 9, color: p.inkMute, marginTop: 2 }}>
                {it.bidders}명 입찰
              </div>
            </div>
          </div>
        )}
      </div>

      <TabBar active="" p={p} />
    </div>);

}

// ── 3. Live auction detail (wyyyes-style: full-bleed video w/ overlays) ─
function MockAuctionDetail() {
  const p = FFMOCK_P,f = FFMOCK_F;
  const cat = CATEGORIES[0];
  // Bright red for the bid CTA — live auction convention
  const RED = '#E63946';
  return (
    <div style={{ background: '#000', minHeight: '100%', position: 'relative',
      paddingTop: 44, paddingBottom: 0, overflow: 'hidden' }}>
      {/* Full-bleed video stream */}
      <div style={{ position: 'absolute', inset: 0, top: 44 }}>
        <ImagePH ratio="auto" label="LIVE · 성주 꿀참외 산지경매"
        p={{ ...p, surfaceAlt: '#2a2820', bgAlt: '#1a1812', bg: '#000', inkMute: '#666' }}
        style={{ width: '100%', height: '100%', borderRadius: 0 }} />
        {/* Subtle vignettes for legibility */}
        <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none',
          background: 'linear-gradient(180deg, rgba(0,0,0,.55) 0%, rgba(0,0,0,0) 22%, rgba(0,0,0,0) 55%, rgba(0,0,0,.85) 100%)' }} />
      </div>

      {/* TOP — host card + live badge + close */}
      <div style={{ position: 'relative', zIndex: 2, padding: '12px 14px 0',
        display: 'flex', alignItems: 'flex-start', gap: 10 }}>
        {/* Host pill */}
        <div style={{ flex: 1, minWidth: 0, display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ width: 38, height: 38, borderRadius: 19, background: cat.hue,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 14, fontWeight: 700, color: '#fff', flexShrink: 0,
            border: '2px solid rgba(255,255,255,.5)' }}>김</div>
          <div style={{ minWidth: 0, flex: 1 }}>
            <div style={{ fontSize: 13, fontWeight: 700, color: '#fff',
              display: 'flex', alignItems: 'center', gap: 6 }}>
              <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                성주 김영농 농가
              </span>
              <span style={{ fontSize: 10 }}>🌱</span>
            </div>
            <div style={{ fontSize: 11, color: 'rgba(255,255,255,.85)', marginTop: 1,
              overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
              GAP 인증 · 오늘 새벽 수확 · 산지직송
            </div>
          </div>
        </div>
        {/* LIVE + watchers */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, flexShrink: 0 }}>
          <div style={{ background: RED, color: '#fff', padding: '4px 8px',
            borderRadius: 4, fontSize: 10, fontWeight: 800, letterSpacing: '0.08em' }}>LIVE</div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 3, color: '#fff', fontSize: 12,
            fontFamily: f.mono, fontWeight: 600 }}>
            <span style={{ fontSize: 11 }}>👁</span>142
          </div>
          <div style={{ width: 26, height: 26, color: '#fff', display: 'flex',
            alignItems: 'center', justifyContent: 'center', fontSize: 16, opacity: .9 }}>×</div>
        </div>
      </div>

      {/* Mute button row (left) + share (right) */}
      <div style={{ position: 'relative', zIndex: 2, padding: '10px 14px 0',
        display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6,
          background: 'rgba(0,0,0,.45)', backdropFilter: 'blur(8px)',
          borderRadius: 999, padding: '5px 10px 5px 8px', color: '#fff' }}>
          <span style={{ fontSize: 11 }}>🔇</span>
          <span style={{ fontSize: 11, fontWeight: 600 }}>소리끄기</span>
          <span style={{ width: 1, height: 10, background: 'rgba(255,255,255,.3)' }} />
          <span style={{ fontSize: 10, color: '#FFD166' }}>🌾</span>
          <span style={{ fontFamily: f.mono, fontSize: 11, fontWeight: 700, color: '#FFD166' }}>0</span>
        </div>
        <div style={{ width: 30, height: 30, borderRadius: 999,
          background: 'rgba(0,0,0,.45)', backdropFilter: 'blur(8px)',
          color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 12 }}>↗</div>
      </div>

      {/* Spacer pushing bottom-stack down */}
      <div style={{ height: 230 }} />

      {/* Floating chat (above the product card) */}
      <div style={{ position: 'relative', zIndex: 2, padding: '0 14px 8px',
        display: 'flex', flexDirection: 'column', gap: 5 }}>
        {[
        ['@소비자맘', '당도 어느정도 나오나요?', null],
        ['@김영농', '15brix 이상 보장드려요 :)', '농가'],
        ['system', '산지경매 시작: 성주 꿀참외 5kg · 박스단위', 'sys'],
        ['@과일러버', '현재 최고가 ₩24,500', '입찰']].
        map(([u, msg, tag], i) =>
        <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 6,
          background: tag === 'sys' ? 'rgba(255,255,255,.92)' : 'rgba(0,0,0,.55)',
          backdropFilter: 'blur(10px)', borderRadius: 999,
          padding: tag === 'sys' ? '6px 12px' : '5px 12px', maxWidth: '88%',
          alignSelf: 'flex-start' }}>
            {tag === 'sys' ?
          <>
                <span style={{ fontSize: 9, fontWeight: 800, background: p.ink,
              color: '#fff', padding: '2px 6px', borderRadius: 3, letterSpacing: '0.04em' }}>
                  산지경매
                </span>
                <span style={{ fontSize: 11, color: p.ink, fontWeight: 500 }}>{msg}</span>
              </> :

          <>
                <span style={{ fontSize: 11, fontWeight: 700,
              color: tag === '농가' ? '#9CD96B' : tag === '입찰' ? '#FFD166' : '#fff' }}>{u}</span>
                <span style={{ fontSize: 11, color: 'rgba(255,255,255,.9)' }}>{msg}</span>
                {tag && tag !== 'sys' &&
            <span style={{ fontFamily: f.mono, fontSize: 8, fontWeight: 800,
              background: tag === '입찰' ? '#FFD166' : '#9CD96B',
              color: '#1a2010', padding: '1px 5px', borderRadius: 2 }}>{tag}</span>
            }
              </>
          }
          </div>
        )}
      </div>

      {/* Current item card — wyyyes-style horizontal product row */}
      <div style={{ position: 'relative', zIndex: 2, padding: '0 14px 10px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 8 }}>
          <span style={{ fontSize: 9, fontWeight: 800, background: '#fff', color: '#1a1812',
            padding: '3px 8px', borderRadius: 4, letterSpacing: '0.06em' }}>🌾 산지경매</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12,
          background: 'rgba(255,255,255,.08)', backdropFilter: 'blur(8px)',
          border: '1px solid rgba(255,255,255,.1)',
          padding: 10, borderRadius: 10 }}>
          <div style={{ width: 56, height: 56, flexShrink: 0, borderRadius: 6,
            overflow: 'hidden' }}>
            <ImagePH ratio="1/1"
            p={{ ...p, surfaceAlt: '#33312b', inkMute: '#aaa', line: '#444' }}
            radius={6} />
          </div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontFamily: f.mono, fontSize: 10, color: 'rgba(255,255,255,.6)',
              marginBottom: 2 }}>#0428</div>
            <div style={{ fontSize: 13, fontWeight: 600, color: '#fff', lineHeight: 1.3,
              overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
              성주 꿀참외 5kg · 박스 단위 🍈
            </div>
          </div>
          <div style={{ textAlign: 'right', flexShrink: 0 }}>
            <div style={{ fontFamily: f.mono, fontSize: 16, fontWeight: 800, color: '#fff' }}>
              24,500원
            </div>
            <div style={{ fontFamily: f.mono, fontSize: 9, color: 'rgba(255,255,255,.55)',
              marginTop: 1, display: 'flex', alignItems: 'center', gap: 3,
              justifyContent: 'flex-end' }}>
              + 산지직송비 <span style={{ fontSize: 10 }}>ⓘ</span>
            </div>
          </div>
        </div>
      </div>

      {/* Big red bid CTA + countdown */}
      <div style={{ position: 'relative', zIndex: 2, padding: '0 14px 8px',
        display: 'flex', alignItems: 'center', gap: 12 }}>
        <button style={{ flex: 1, height: 52, background: RED, border: 0,
          borderRadius: 8, color: '#fff', fontSize: 16, fontWeight: 800,
          letterSpacing: '-0.01em', display: 'flex', alignItems: 'center',
          justifyContent: 'center', gap: 6,
          boxShadow: '0 4px 14px rgba(230,57,70,.5)' }}>
          25,000원 입찰 <span style={{ fontFamily: f.mono, fontWeight: 600 }}>»</span>
        </button>
        <div style={{ flexShrink: 0, textAlign: 'right' }}>
          <div style={{ fontFamily: f.mono, fontSize: 22, fontWeight: 800, color: '#fff',
            letterSpacing: '0.02em', fontVariantNumeric: 'tabular-nums', lineHeight: 1 }}>
            00:29
          </div>
          <div style={{ fontSize: 9, color: 'rgba(255,255,255,.6)', marginTop: 2,
            letterSpacing: '0.04em' }}>경매 마감</div>
        </div>
      </div>

      {/* Bottom toolbar */}
      <div style={{ position: 'relative', zIndex: 2, padding: '8px 12px 14px',
        display: 'flex', alignItems: 'center', gap: 8,
        borderTop: '1px solid rgba(255,255,255,.08)' }}>
        {/* Mini live preview */}
        <div style={{ width: 38, height: 38, borderRadius: 6, overflow: 'hidden',
          flexShrink: 0, position: 'relative',
          border: '1.5px solid rgba(255,255,255,.25)' }}>
          <ImagePH ratio="1/1"
          p={{ ...p, surfaceAlt: '#2a2820', inkMute: '#666', line: '#444' }}
          radius={4} />
          <div style={{ position: 'absolute', top: 2, left: 2, background: RED,
            color: '#fff', fontSize: 7, fontWeight: 800, padding: '1px 3px',
            borderRadius: 2, letterSpacing: '0.04em' }}>LIVE</div>
        </div>
        {/* Message input */}
        <div style={{ flex: 1, height: 38, borderRadius: 999,
          background: 'rgba(255,255,255,.1)', border: '1px solid rgba(255,255,255,.15)',
          display: 'flex', alignItems: 'center', padding: '0 14px',
          fontSize: 12, color: 'rgba(255,255,255,.55)' }}>
          메시지 입력
        </div>
        {/* Action icons */}
        {['🌾', '↗', '📋'].map((ic, i) =>
        <div key={i} style={{ width: 34, height: 34, borderRadius: 999,
          background: 'rgba(255,255,255,.08)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          color: '#fff', fontSize: 14, flexShrink: 0 }}>{ic}</div>
        )}
      </div>
    </div>);
}

// ── 3b. 진행중인 라이브 모달 (전체 라이브 그리드) ────────────────────────
function MockLiveDirectory() {
  const p = FFMOCK_P,f = FFMOCK_F;
  const items = [
  { host: '성주 김영농', cat: CATEGORIES[0], title: '꿀참외 새벽수확 직판 — 박스단위', viewers: 142, tag: null },
  { host: '평창 산너머', cat: CATEGORIES[1], title: '강원 평창 700m 고랭지 옥수수 산지경매', viewers: 98, tag: '공동구매' },
  { host: '제주 한라푸드', cat: CATEGORIES[2], title: '한라봉 만감류 / 1박스 5kg', viewers: 64, tag: null },
  { host: '해남 들녘', cat: CATEGORIES[0], title: '해남 꿀고구마 산지직송 LIVE', viewers: 211, tag: null }];

  return (
    <div style={{ background: '#0e0d0b', minHeight: '100%', display: 'flex',
      flexDirection: 'column' }}>
      {/* Modal header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '52px 18px 14px' }}>
        <div style={{ fontSize: 18, fontWeight: 800, color: '#fff', letterSpacing: '-0.01em' }}>
          진행중인 라이브
        </div>
        <div style={{ width: 26, height: 26, color: '#fff', display: 'flex',
          alignItems: 'center', justifyContent: 'center', fontSize: 18, opacity: .8 }}>×</div>
      </div>

      {/* Info banner */}
      <div style={{ margin: '0 18px 14px', padding: '12px 14px',
        background: 'rgba(255,255,255,.06)', borderRadius: 8,
        border: '1px solid rgba(255,255,255,.08)',
        display: 'flex', gap: 8, alignItems: 'flex-start' }}>
        <div style={{ width: 18, height: 18, borderRadius: 9,
          background: 'rgba(255,255,255,.12)', color: '#fff',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 11, flexShrink: 0, marginTop: 1 }}>ⓘ</div>
        <div style={{ fontSize: 11, color: 'rgba(255,255,255,.78)', lineHeight: 1.5 }}>
          내 관심 작물·산지를 바탕으로, 모든 카테고리의 산지경매 라이브가 보여집니다.
        </div>
      </div>

      {/* Filter */}
      <div style={{ padding: '0 18px 14px', display: 'flex', alignItems: 'center', gap: 8 }}>
        <div style={{ width: 16, height: 16, border: '1.5px solid rgba(255,255,255,.5)',
          borderRadius: 3 }} />
        <div style={{ fontSize: 13, color: '#fff', fontWeight: 600 }}>
          내 관심 작물 라이브만 보기
        </div>
      </div>

      {/* Grid */}
      <div style={{ flex: 1, padding: '0 14px', display: 'grid',
        gridTemplateColumns: '1fr 1fr', gap: 10, overflowY: 'auto' }}>
        {items.map((it, i) =>
        <div key={i} style={{ position: 'relative', borderRadius: 10, overflow: 'hidden',
          background: '#1a1812' }}>
            {/* Thumb */}
            <div style={{ aspectRatio: '1/1.1', position: 'relative' }}>
              <ImagePH ratio="auto" label={it.cat.ko}
            p={{ ...p, surfaceAlt: it.cat.hue + '40', bgAlt: it.cat.hue + '20',
              inkMute: 'rgba(255,255,255,.5)', line: 'rgba(255,255,255,.1)' }}
            style={{ width: '100%', height: '100%', borderRadius: 0 }} />
              <div style={{ position: 'absolute', top: 6, left: 6,
              background: '#E63946', color: '#fff', fontSize: 9, fontWeight: 800,
              padding: '3px 6px', borderRadius: 3, letterSpacing: '0.06em' }}>LIVE</div>
              {it.tag &&
            <div style={{ position: 'absolute', top: 6, right: 6,
              background: 'rgba(255,255,255,.95)', color: '#1a1812',
              fontSize: 9, fontWeight: 700, padding: '3px 7px', borderRadius: 3 }}>
                  {it.tag}
                </div>
            }
              <div style={{ position: 'absolute', left: 6, bottom: 6,
              display: 'flex', alignItems: 'center', gap: 5 }}>
                <div style={{ width: 18, height: 18, borderRadius: 9, background: it.cat.hue,
                border: '1.5px solid rgba(255,255,255,.6)', flexShrink: 0 }} />
                <div style={{ fontSize: 10, fontWeight: 600, color: '#fff',
                textShadow: '0 1px 2px rgba(0,0,0,.5)' }}>{it.host}</div>
              </div>
            </div>
            {/* Meta */}
            <div style={{ padding: '8px 10px 10px' }}>
              <div style={{ fontSize: 11, fontWeight: 600, color: '#fff', lineHeight: 1.35,
              height: 30, overflow: 'hidden' }}>
                {it.title}
              </div>
              <div style={{ marginTop: 4, fontFamily: f.mono, fontSize: 10,
              color: 'rgba(255,255,255,.55)' }}>
                <span style={{ fontSize: 9 }}>👁</span> {it.viewers}명 참여 중
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Bottom CTA row */}
      <div style={{ padding: '14px 14px 22px', display: 'flex', gap: 8 }}>
        <button style={{ flex: 1, height: 48, background: 'rgba(255,255,255,.08)',
          border: '1px solid rgba(255,255,255,.12)', borderRadius: 8,
          color: '#fff', fontSize: 13, fontWeight: 600 }}>관심 작물 설정</button>
        <button style={{ flex: 1, height: 48, background: '#E63946', border: 0,
          borderRadius: 8, color: '#fff', fontSize: 14, fontWeight: 700 }}>
          닫기
        </button>
      </div>
    </div>);
}

// ── 3c. 라이브중인 상품 모달 (탭 구조) ─────────────────────────────────
function MockLiveProductList() {
  const p = FFMOCK_P,f = FFMOCK_F;
  const tabs = ['공동구매', '상품 목록', '판매 완료', '구매 내역'];
  const activeTab = 2; // '판매 완료'
  const sold = [
  { buyer: '서울맘', avatar: '🌷', no: '#28', title: '성주 꿀참외 5kg · 박스단위 🍈 산지경매', price: 24500, time: '오후 11시 34분' },
  { buyer: '엄마손맛', avatar: '🍳', no: '#27', title: '성주 꿀참외 5kg · 박스단위 🍈 산지경매', price: 22000, time: '오후 11시 32분' },
  { buyer: '주말농부', avatar: '🌾', no: '#26', title: '성주 꿀참외 5kg · 박스단위 🍈 산지경매', price: 28500, time: '오후 11시 30분' },
  { buyer: '도시농부', avatar: '🥕', no: '#25', title: '성주 꿀참외 5kg · 박스단위 🍈 산지경매', price: 19000, time: '오후 11시 26분' }];

  return (
    <div style={{ background: '#0e0d0b', minHeight: '100%', display: 'flex',
      flexDirection: 'column' }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '52px 18px 14px' }}>
        <div style={{ fontSize: 18, fontWeight: 800, color: '#fff', letterSpacing: '-0.01em' }}>
          라이브중인 상품
        </div>
        <div style={{ width: 26, height: 26, color: '#fff', display: 'flex',
          alignItems: 'center', justifyContent: 'center', fontSize: 18, opacity: .8 }}>×</div>
      </div>

      {/* Tabs */}
      <div style={{ display: 'flex', padding: '0 18px',
        borderBottom: '1px solid rgba(255,255,255,.08)' }}>
        {tabs.map((t, i) => {
          const active = i === activeTab;
          return (
            <div key={t} style={{ flex: 1, position: 'relative',
              padding: '12px 0', display: 'flex', alignItems: 'center',
              justifyContent: 'center', gap: 5,
              fontSize: 12, fontWeight: active ? 700 : 500,
              color: active ? '#fff' : 'rgba(255,255,255,.55)' }}>
              {t}
              {i === 1 && <span style={{ background: '#E63946', color: '#fff',
                fontSize: 9, fontWeight: 800, width: 16, height: 16, borderRadius: 8,
                display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}>1</span>}
              {active && <div style={{ position: 'absolute', bottom: -1, left: 8, right: 8,
                height: 2, background: '#fff' }} />}
            </div>);

        })}
      </div>

      {/* Info banner */}
      <div style={{ margin: '14px 18px 14px', padding: '12px 14px',
        background: 'rgba(255,255,255,.06)', borderRadius: 8,
        border: '1px solid rgba(255,255,255,.08)',
        display: 'flex', gap: 8, alignItems: 'flex-start' }}>
        <div style={{ width: 18, height: 18, borderRadius: 9,
          background: 'rgba(255,255,255,.12)', color: '#fff',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 11, flexShrink: 0, marginTop: 1 }}>ⓘ</div>
        <div style={{ fontSize: 11, color: 'rgba(255,255,255,.78)', lineHeight: 1.5 }}>
          산지직송 신선식품의 특성상, 출하 후에는 단순변심에 의한 반품이 어려워요. (상품 하자는 예외)
        </div>
      </div>

      {/* List */}
      <div style={{ flex: 1, padding: '0 14px', display: 'flex',
        flexDirection: 'column', gap: 10, overflowY: 'auto' }}>
        {sold.map((s, i) =>
        <div key={i} style={{ background: 'rgba(255,255,255,.05)',
          border: '1px solid rgba(255,255,255,.08)',
          borderRadius: 10, padding: 12, display: 'flex', gap: 10 }}>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 6 }}>
                <div style={{ width: 22, height: 22, borderRadius: 11,
                background: 'rgba(255,255,255,.12)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 12 }}>{s.avatar}</div>
                <div style={{ fontSize: 12, fontWeight: 600, color: '#fff' }}>{s.buyer}</div>
              </div>
              <div style={{ fontSize: 12, fontWeight: 600, color: '#fff', lineHeight: 1.4,
              overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                {s.no} {s.title}
              </div>
              <div style={{ marginTop: 4, fontSize: 12, color: '#fff' }}>
                낙찰가: <span style={{ fontFamily: f.mono, fontWeight: 700 }}>
                  {s.price.toLocaleString()}원
                </span>
              </div>
              <div style={{ marginTop: 2, fontFamily: f.mono, fontSize: 10,
              color: 'rgba(255,255,255,.5)' }}>
                2026. 04. 30(목) {s.time}
              </div>
            </div>
            <div style={{ width: 56, height: 56, flexShrink: 0, borderRadius: 6,
            overflow: 'hidden' }}>
              <ImagePH ratio="1/1"
            p={{ ...p, surfaceAlt: '#33312b', inkMute: '#666', line: '#333' }}
            radius={6} />
            </div>
          </div>
        )}
      </div>

      {/* Bottom CTA */}
      <div style={{ padding: '14px 18px 22px' }}>
        <button style={{ width: '100%', height: 50, background: 'rgba(255,255,255,.08)',
          border: '1px solid rgba(255,255,255,.15)', borderRadius: 8,
          color: '#fff', fontSize: 14, fontWeight: 700 }}>닫기</button>
      </div>
    </div>);
}

// ── 4. Bid confirm modal ───────────────────────────────────────────────
function MockBidConfirm() {
  const p = FFMOCK_P,f = FFMOCK_F;
  return (
    <div style={{ background: 'rgba(31,36,23,.5)', minHeight: '100%',
      display: 'flex', flexDirection: 'column', justifyContent: 'flex-end',
      backdropFilter: 'blur(4px)' }}>
      <div style={{ background: p.bg, borderTopLeftRadius: 24, borderTopRightRadius: 24,
        padding: '18px 20px 30px', maxHeight: '72%', overflow: 'auto' }}>
        <div style={{ width: 36, height: 4, borderRadius: 2, background: p.line,
          margin: '0 auto 18px' }} />

        <div style={{ fontSize: 11, fontFamily: f.mono, letterSpacing: '0.08em',
          textTransform: 'uppercase', color: p.inkMute }}>
          BID CONFIRMATION
        </div>
        <div style={{ fontSize: 24, fontWeight: 800, color: p.ink,
          letterSpacing: '-0.02em', marginTop: 4 }}>
          ₩25,300원/박스에 입찰하시겠어요?
        </div>
        <div style={{ marginTop: 6, fontSize: 13, color: p.inkSoft, lineHeight: 1.5 }}>
          낙찰 시 산지에서 직접 출하됩니다. 입찰은 취소할 수 없어요.
        </div>

        {/* Item summary */}
        <div style={{ marginTop: 18, padding: 12, background: p.surface,
          border: `1px solid ${p.line}`, borderRadius: FFMOCK_R,
          display: 'flex', gap: 12, alignItems: 'center' }}>
          <div style={{ width: 56, height: 56, flexShrink: 0 }}>
            <ImagePH ratio="1/1" p={p} radius={6} />
          </div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 13, fontWeight: 600, color: p.ink, lineHeight: 1.3 }}>
              성주 꿀참외 5kg · 1박스
            </div>
            <div style={{ marginTop: 3, fontSize: 11, color: p.inkMute, fontFamily: f.mono }}>
              현재가 ₩24,800 · 02:14 남음
            </div>
          </div>
        </div>

        {/* Breakdown */}
        <div style={{ marginTop: 14, padding: 14, background: p.surface,
          border: `1px solid ${p.line}`, borderRadius: FFMOCK_R }}>
          {[
          ['낙찰가 (1박스)', '₩25,300', false],
          ['수수료 (3%)', '₩759', false],
          ['산지 직송 배송비', '₩3,000', false],
          ['예상 결제 금액', '₩29,059', true]].
          map(([k, v, bold], i, arr) =>
          <div key={k} style={{ display: 'flex', justifyContent: 'space-between',
            padding: '6px 0',
            borderTop: i > 0 ? `1px solid ${p.lineSoft}` : 'none',
            paddingTop: i === arr.length - 1 ? 12 : 6,
            marginTop: i === arr.length - 1 ? 6 : 0 }}>
              <div style={{ fontSize: bold ? 14 : 13, fontWeight: bold ? 700 : 400,
              color: bold ? p.ink : p.inkSoft }}>{k}</div>
              <div style={{ fontSize: bold ? 16 : 13, fontWeight: bold ? 700 : 500,
              color: p.ink, fontFamily: bold ? f.body : f.mono,
              letterSpacing: bold ? '-0.01em' : '0' }}>{v}</div>
            </div>
          )}
        </div>

        {/* Payment method */}
        <div style={{ marginTop: 14, padding: '12px 14px', background: p.surface,
          border: `1px solid ${p.line}`, borderRadius: FFMOCK_R,
          display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ width: 34, height: 22, borderRadius: 3, background: p.success,
            color: '#fff', fontSize: 9, fontWeight: 700,
            display: 'flex', alignItems: 'center', justifyContent: 'center' }}>NH</div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 12, fontWeight: 600, color: p.ink }}>NH농협카드</div>
            <div style={{ fontSize: 10, color: p.inkMute, fontFamily: f.mono }}>**** 4521</div>
          </div>
          <div style={{ fontSize: 12, color: p.accent }}>변경</div>
        </div>

        <button style={{ marginTop: 18, width: '100%', height: 54, background: p.accent,
          color: p.accentInk, border: 'none', borderRadius: FFMOCK_R,
          fontSize: 16, fontWeight: 700 }}>₩25,300원 입찰</button>
        <button style={{ marginTop: 8, width: '100%', height: 44, background: 'transparent',
          color: p.inkSoft, border: 'none', fontSize: 14, fontWeight: 500 }}>
          취소
        </button>
      </div>
    </div>);

}

// ── 5. My page ─────────────────────────────────────────────────────────
function MockMyPage() {
  const p = FFMOCK_P,f = FFMOCK_F;
  const items = [
  { status: 'won', cat: CATEGORIES[0], title: '성주 꿀참외 5kg · 1박스', price: '25,300', sub: '낙찰 · 결제 대기' },
  { status: 'leading', cat: CATEGORIES[1], title: '평창 유기농 감자 10kg', price: '18,200', sub: '최고 입찰자 · 5분 남음' },
  { status: 'outbid', cat: CATEGORIES[3], title: '횡성 한우 1++ 등심 1kg', price: '128,000', sub: '경합 중 · 다른 입찰자가 더 높음' },
  { status: 'lost', cat: CATEGORIES[2], title: '이천 햅쌀 20kg', price: '62,000', sub: '유찰 · 시작가 미달' }];

  const statusMap = {
    won: { label: '낙찰', bg: p.success, fg: '#fff' },
    leading: { label: '입찰 중', bg: p.accent, fg: p.accentInk },
    outbid: { label: '경합', bg: p.warning, fg: '#fff' },
    lost: { label: '유찰', bg: p.surfaceMute, fg: p.ink }
  };

  return (
    <div style={{ background: p.bg, minHeight: '100%', paddingBottom: 80 }}>
      {/* Header */}
      <div style={{ padding: '62px 20px 20px' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ width: 56, height: 56, borderRadius: 28, background: p.accentSoft,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            color: p.accentDeep, fontSize: 22, fontWeight: 700 }}>Y</div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 16, fontWeight: 700, color: p.ink }}>@youname</div>
            <div style={{ fontSize: 11, color: p.inkMute, fontFamily: f.mono, marginTop: 2 }}>
              NH농협 단골고객 · 12개월 차
            </div>
          </div>
          <div style={{ width: 36, height: 36, borderRadius: 18, background: p.surface,
            border: `1px solid ${p.line}`, display: 'flex', alignItems: 'center',
            justifyContent: 'center', fontSize: 14 }}>⚙</div>
        </div>

        {/* Stats */}
        <div style={{ marginTop: 18, display: 'grid', gridTemplateColumns: 'repeat(3,1fr)',
          gap: 8 }}>
          {[['진행중', '3'], ['낙찰', '12'], ['관심', '27']].map(([k, v]) =>
          <div key={k} style={{ background: p.surface, border: `1px solid ${p.line}`,
            borderRadius: FFMOCK_R, padding: '12px', textAlign: 'center' }}>
              <div style={{ fontSize: 20, fontWeight: 800, color: p.ink, letterSpacing: '-0.02em' }}>{v}</div>
              <div style={{ fontSize: 10, color: p.inkMute, fontFamily: f.mono,
              letterSpacing: '0.06em', textTransform: 'uppercase', marginTop: 2 }}>{k}</div>
            </div>
          )}
        </div>
      </div>

      {/* Tabs */}
      <div style={{ display: 'flex', gap: 0, borderBottom: `1px solid ${p.line}`,
        padding: '0 20px' }}>
        {['내 입찰', '구매내역', '관심상품', '알림'].map((t, i) =>
        <div key={t} style={{ padding: '10px 12px', fontSize: 13,
          fontWeight: i === 0 ? 700 : 500,
          color: i === 0 ? p.ink : p.inkMute,
          borderBottom: i === 0 ? `2px solid ${p.accent}` : '2px solid transparent',
          marginBottom: -1 }}>{t}</div>
        )}
      </div>

      {/* Item list */}
      <div style={{ padding: '12px 20px', display: 'flex', flexDirection: 'column', gap: 10 }}>
        {items.map((it, i) => {
          const s = statusMap[it.status];
          return (
            <div key={i} style={{ background: p.surface, border: `1px solid ${p.line}`,
              borderRadius: FFMOCK_R, padding: 12, display: 'flex', gap: 12 }}>
              <div style={{ width: 64, height: 64, flexShrink: 0, position: 'relative' }}>
                <ImagePH ratio="1/1" p={p} radius={6} />
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display: 'flex', gap: 6, alignItems: 'center', flexWrap: 'wrap' }}>
                  <span style={{ background: s.bg, color: s.fg, padding: '3px 8px',
                    borderRadius: 3, fontSize: 10, fontWeight: 700 }}>{s.label}</span>
                  <CatBadge cat={it.cat} p={p} ghost />
                </div>
                <div style={{ marginTop: 5, fontSize: 13, fontWeight: 600, color: p.ink,
                  lineHeight: 1.3,
                  whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                  {it.title}
                </div>
                <div style={{ marginTop: 3, fontSize: 11, color: p.inkMute }}>{it.sub}</div>
                <div style={{ marginTop: 5, fontSize: 14, fontWeight: 700, color: p.ink,
                  letterSpacing: '-0.01em' }}>₩{it.price}</div>
              </div>
              {it.status === 'won' &&
              <div style={{ alignSelf: 'center' }}>
                  <button style={{ background: p.accent, color: p.accentInk, border: 'none',
                  padding: '8px 12px', borderRadius: FFMOCK_R - 2, fontSize: 11, fontWeight: 600 }}>
                    결제
                  </button>
                </div>
              }
            </div>);

        })}
      </div>

      <TabBar active="me" p={p} />
    </div>);

}

// ── 6. Checkout / Shipping ─────────────────────────────────────────────
function MockCheckout() {
  const p = FFMOCK_P,f = FFMOCK_F;
  return (
    <div style={{ background: p.bg, minHeight: '100%' }}>
      {/* Header */}
      <div style={{ padding: '62px 20px 14px', display: 'flex', alignItems: 'center', gap: 14 }}>
        <span style={{ fontSize: 18 }}>‹</span>
        <div style={{ fontSize: 16, fontWeight: 700, color: p.ink, flex: 1 }}>결제하기</div>
        <span style={{ fontSize: 11, color: p.inkMute, fontFamily: f.mono }}>STEP 2/3</span>
      </div>

      {/* Item summary */}
      <div style={{ margin: '0 20px', padding: 12, background: p.surface,
        border: `1px solid ${p.line}`, borderRadius: FFMOCK_R, display: 'flex', gap: 12 }}>
        <div style={{ width: 48, height: 48, flexShrink: 0 }}>
          <ImagePH ratio="1/1" p={p} radius={6} />
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 12, fontWeight: 600, color: p.ink, lineHeight: 1.3 }}>
            성주 꿀참외 5kg · 1박스
          </div>
          <div style={{ marginTop: 4, fontSize: 14, fontWeight: 700, color: p.ink }}>
            ₩25,300
          </div>
        </div>
      </div>

      {/* Section: Shipping */}
      <Section label="배송 정보" p={p} f={f}>
        <Field label="받는 분" p={p}>
          <input defaultValue="김유저" style={inputStyle(p)} />
        </Field>
        <div style={{ display: 'flex', gap: 8 }}>
          <div style={{ flex: 1 }}>
            <Field label="연락처" p={p}>
              <input defaultValue="010-1234-5678" style={inputStyle(p)} />
            </Field>
          </div>
        </div>
        <Field label="주소" hint="우편번호 검색" p={p}>
          <input defaultValue="04524" style={{ ...inputStyle(p), marginBottom: 8 }} />
          <input defaultValue="서울 중구 세종대로 110" style={{ ...inputStyle(p), marginBottom: 8 }} />
          <input placeholder="상세주소" style={inputStyle(p)} />
        </Field>
        <Field label="배송 메모" p={p}>
          <select style={inputStyle(p)}>
            <option>경비실에 맡겨주세요</option>
          </select>
        </Field>
      </Section>

      {/* Payment */}
      <Section label="결제 수단" p={p} f={f}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {[
          ['신한카드 **** 4521', true, 'VISA'],
          ['카카오페이', false, 'PAY'],
          ['새 카드 추가', false, '+']].
          map(([name, sel, badge], i) =>
          <div key={i} style={{ padding: '12px 14px',
            background: sel ? p.accentSoft + '55' : p.surface,
            border: `1.5px solid ${sel ? p.accent : p.line}`,
            borderRadius: FFMOCK_R, display: 'flex', alignItems: 'center', gap: 12 }}>
              <div style={{ width: 34, height: 22, borderRadius: 3, background: p.ink,
              color: p.bg, fontSize: 9, fontWeight: 700,
              display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{badge}</div>
              <div style={{ flex: 1, fontSize: 13, fontWeight: 600, color: p.ink }}>{name}</div>
              <div style={{ width: 18, height: 18, borderRadius: 9,
              border: `2px solid ${sel ? p.accent : p.line}`,
              background: sel ? p.accent : 'transparent',
              position: 'relative' }}>
                {sel && <div style={{ position: 'absolute', inset: 3, borderRadius: '50%',
                background: '#fff' }} />}
              </div>
            </div>
          )}
        </div>
      </Section>

      {/* Total + CTA */}
      <div style={{ position: 'sticky', bottom: 0,
        background: p.bg, padding: '14px 20px 30px', borderTop: `1px solid ${p.line}`,
        marginTop: 14 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 12 }}>
          <div style={{ fontSize: 13, color: p.inkSoft }}>총 결제 금액</div>
          <div style={{ fontSize: 20, fontWeight: 800, color: p.ink, letterSpacing: '-0.02em' }}>
            ₩29,059
          </div>
        </div>
        <button style={{ width: '100%', height: 54, background: p.accent,
          color: p.accentInk, border: 'none', borderRadius: FFMOCK_R,
          fontSize: 16, fontWeight: 700 }}>결제하기</button>
      </div>
    </div>);

}

function Section({ label, children, p, f }) {
  return (
    <div style={{ marginTop: 20, padding: '0 20px' }}>
      <div style={{ fontSize: 11, fontFamily: f.mono, letterSpacing: '0.08em',
        textTransform: 'uppercase', color: p.inkMute, marginBottom: 10 }}>{label}</div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>{children}</div>
    </div>);

}

function Field({ label, hint, children, p }) {
  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
        <div style={{ fontSize: 12, fontWeight: 600, color: p.ink }}>{label}</div>
        {hint && <div style={{ fontSize: 11, color: p.accent, fontWeight: 600 }}>{hint}</div>}
      </div>
      {children}
    </div>);

}

function inputStyle(p) {
  return {
    width: '100%', height: 44, padding: '0 14px',
    border: `1px solid ${p.line}`, borderRadius: FFMOCK_R,
    background: p.surface, color: p.ink,
    fontFamily: FFMOCK_F.body, fontSize: 14, outline: 'none'
  };
}

// ── 7. Barofarm Home (Weiss-benchmark, dark) ────────────────────────────
// NH바로팜 라이브 커머스 홈. 와이스 레퍼런스를 기반으로 하되
// 농산물 산지직송에 맞게 카테고리/색감/메시지를 재구성.

// 농산물 라이브 카테고리 (이모지 대신 색감 있는 SVG 글리프)
const BF_CATS = [
{ id: 'all', ko: '전체', glyph: 'cart', hue: '#7BC470' },
{ id: 'fruit', ko: '과일', glyph: 'apple', hue: '#E5564A' },
{ id: 'veg', ko: '채소', glyph: 'leaf', hue: '#4FA84F' },
{ id: 'meat', ko: '축산', glyph: 'meat', hue: '#C84B5C' },
{ id: 'sea', ko: '수산', glyph: 'fish', hue: '#4A8FBF' },
{ id: 'grain', ko: '곡물', glyph: 'grain', hue: '#D6A84A' },
{ id: 'flower', ko: '화훼', glyph: 'flower', hue: '#B86A9C' },
{ id: 'spec', ko: '특산', glyph: 'star', hue: '#6FB4A0' }];


// 부 카테고리 (와이스의 "나루토/짱구" 자리 — 산지/시즌 키워드)
const BF_TAGS = [
{ ko: '제철특가', glyph: 'fire' },
{ ko: '새벽수확', glyph: 'sun' },
{ ko: 'GAP인증', glyph: 'cert' },
{ ko: '유기농', glyph: 'leaf2' },
{ ko: '공동구매', glyph: 'group' },
{ ko: '친환경', glyph: 'leaf2' }];


// SVG 글리프 — 단순한 모던 도형. 카테고리 색에 맞춰 fill만 변경.
function BFGlyph({ kind, color = '#fff', size = 30 }) {
  const s = size;
  switch (kind) {
    case 'cart':return (
        <svg width={s} height={s} viewBox="0 0 32 32" fill="none">
        <path d="M5 8h4l3 13h13l3-9H10" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        <circle cx="13" cy="26" r="2" fill={color} />
        <circle cx="23" cy="26" r="2" fill={color} />
        <path d="M19 4c1 1.5 2 2 3 2.2M22 7c-.5-1.2-.3-2.5.5-3.2" stroke={color} strokeWidth="1.5" strokeLinecap="round" />
      </svg>);
    case 'apple':return (
        <svg width={s} height={s} viewBox="0 0 32 32" fill="none">
        <path d="M16 9c0-2 1.5-3.5 3.5-3.5M16 9c-3-2-7-1-8.5 1.5-2 3-1 8 2 11 1.5 1.5 3 2 4.5 2 1 0 1.5-.5 2-.5s1 .5 2 .5c1.5 0 3-.5 4.5-2 3-3 4-8 2-11C21 7 19 6 16 9z" fill={color} />
        <path d="M17 5c1-2 3-2.5 4-2-.2 2-1.5 3.5-3 3.5" fill={color} opacity=".7" />
      </svg>);
    case 'leaf':return (
        <svg width={s} height={s} viewBox="0 0 32 32" fill="none">
        <path d="M6 22c0-9 7-16 20-16-1 13-9 20-16 20-1.5 0-3-.5-4-1.5z" fill={color} />
        <path d="M8 24c4-4 9-8 16-12" stroke="#fff" strokeOpacity=".4" strokeWidth="1.5" strokeLinecap="round" />
      </svg>);
    case 'meat':return (
        <svg width={s} height={s} viewBox="0 0 32 32" fill="none">
        <path d="M9 8c4-3 11-3 14 0 3 3 3 9 0 12-2 2-5 2.5-7 4-2 1.5-5 1-6.5-1-1.5-2-1-4 .5-5C8 16 6 11 9 8z" fill={color} />
        <circle cx="13" cy="14" r="2" fill="#fff" opacity=".5" />
      </svg>);
    case 'fish':return (
        <svg width={s} height={s} viewBox="0 0 32 32" fill="none">
        <path d="M4 16c4-6 10-8 16-6 3 1 5 3 6 4l4-4v12l-4-4c-1 1-3 3-6 4-6 2-12 0-16-6z" fill={color} />
        <circle cx="11" cy="14" r="1.2" fill="#0a0a0a" />
      </svg>);
    case 'grain':return (
        <svg width={s} height={s} viewBox="0 0 32 32" fill="none">
        <path d="M16 4v24" stroke={color} strokeWidth="2" strokeLinecap="round" />
        <path d="M16 8c-3-1-6 0-7 3 3 1 6 0 7-3zM16 8c3-1 6 0 7 3-3 1-6 0-7-3zM16 14c-3-1-6 0-7 3 3 1 6 0 7-3zM16 14c3-1 6 0 7 3-3 1-6 0-7-3zM16 20c-3-1-6 0-7 3 3 1 6 0 7-3zM16 20c3-1 6 0 7 3-3 1-6 0-7-3z" fill={color} />
      </svg>);
    case 'flower':return (
        <svg width={s} height={s} viewBox="0 0 32 32" fill="none">
        <circle cx="16" cy="11" r="4" fill={color} />
        <circle cx="11" cy="16" r="4" fill={color} />
        <circle cx="21" cy="16" r="4" fill={color} />
        <circle cx="16" cy="21" r="4" fill={color} />
        <circle cx="16" cy="16" r="2.5" fill="#fff" />
      </svg>);
    case 'star':return (
        <svg width={s} height={s} viewBox="0 0 32 32" fill="none">
        <path d="M16 4l3.5 7.5 8 1-6 6 1.5 8L16 22.5 9 26.5l1.5-8-6-6 8-1L16 4z" fill={color} />
      </svg>);
    case 'fire':return (
        <svg width={s} height={s} viewBox="0 0 24 24" fill="none">
        <path d="M12 3c1 3-1 5-2 7s-2 4 2 6c5 1.5 6-3 5-6-1 1-2 1-2 1s2-4-3-8z" fill="#FF8A4C" />
      </svg>);
    case 'sun':return (
        <svg width={s} height={s} viewBox="0 0 24 24" fill="none">
        <circle cx="12" cy="12" r="4" fill="#FFC857" />
        <g stroke="#FFC857" strokeWidth="1.6" strokeLinecap="round">
          <path d="M12 3v3M12 18v3M3 12h3M18 12h3M5.5 5.5l2 2M16.5 16.5l2 2M5.5 18.5l2-2M16.5 7.5l2-2" />
        </g>
      </svg>);
    case 'cert':return (
        <svg width={s} height={s} viewBox="0 0 24 24" fill="none">
        <path d="M12 3l8 3v6c0 5-4 8-8 9-4-1-8-4-8-9V6l8-3z" fill="#7BC470" />
        <path d="M8 12l3 3 5-6" stroke="#0c1108" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
      </svg>);
    case 'leaf2':return (
        <svg width={s} height={s} viewBox="0 0 24 24" fill="none">
        <path d="M4 18C4 9 10 4 20 4c0 10-5 16-14 16-1 0-2 0-2-2z" fill="#4FA84F" />
      </svg>);
    case 'group':return (
        <svg width={s} height={s} viewBox="0 0 24 24" fill="none">
        <circle cx="8" cy="9" r="3" fill="#5BA3E0" />
        <circle cx="16" cy="9" r="3" fill="#5BA3E0" />
        <path d="M3 19c0-3 2.5-5 5-5s5 2 5 5M11 19c0-3 2.5-5 5-5s5 2 5 5" stroke="#5BA3E0" strokeWidth="1.8" strokeLinecap="round" fill="none" />
      </svg>);
    default:return null;
  }
}

// 라이브 카드 — 밝은 테마, 고령층 친화 (큰 글씨, 명확한 정보 위계)
function BFLiveCard({ item, C }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 10,
      background: '#FFFFFF', borderRadius: 16,
      border: `1px solid ${C.line}`,
      boxShadow: '0 2px 8px rgba(20,30,15,.04)',
      overflow: 'hidden' }}>
      <div style={{ position: 'relative', aspectRatio: '1/1',
        background: `linear-gradient(135deg, ${item.bg1}, ${item.bg2})` }}>
        <div style={{ position: 'absolute', inset: 0,
          backgroundImage: `repeating-linear-gradient(135deg, rgba(255,255,255,.06), rgba(255,255,255,.06) 8px, rgba(0,0,0,.05) 8px, rgba(0,0,0,.05) 16px)` }} />
        <div style={{ position: 'absolute', right: -16, bottom: -16, opacity: .35 }}>
          <BFGlyph kind={item.glyph} color="#fff" size={150} />
        </div>
        {/* LIVE — 큼직한 배지 */}
        <div style={{ position: 'absolute', top: 10, left: 10,
          background: '#E63946', color: '#fff',
          fontSize: 13, fontWeight: 900, letterSpacing: '0.06em',
          padding: '5px 12px', borderRadius: 6,
          display: 'inline-flex', alignItems: 'center', gap: 6,
          boxShadow: '0 2px 8px rgba(230,57,70,.35)' }}>
          <span style={{ width: 7, height: 7, borderRadius: 4, background: '#fff' }} />
          LIVE
        </div>
        {/* 참여자 수 — 우상단 */}
        <div style={{ position: 'absolute', top: 10, right: 10,
          background: 'rgba(0,0,0,.6)', color: '#fff',
          fontSize: 13, fontWeight: 700,
          padding: '5px 10px', borderRadius: 999 }}>
          👁 {item.viewers}
        </div>
      </div>
      <div style={{ padding: '4px 14px 14px' }}>
        {/* 농가 */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
          <div style={{ width: 26, height: 26, borderRadius: 13, background: item.bg1,
            color: '#fff', flexShrink: 0,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 12, fontWeight: 800 }}>
            {item.hostInitial}
          </div>
          <div style={{ fontSize: 13, fontWeight: 700, color: C.ink,
            overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
            {item.host}
          </div>
        </div>
        {/* 타이틀 — 크고 진하게 */}
        <div style={{ fontSize: 15, fontWeight: 700, color: C.ink, lineHeight: 1.4,
          height: 42, overflow: 'hidden',
          display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical' }}>
          {item.title}
        </div>
        {/* 현재가 — 가장 큰 텍스트 */}
        <div style={{ marginTop: 10, paddingTop: 10,
          borderTop: `1px solid ${C.line}` }}>
          <div style={{ fontSize: 11, color: C.inkMute, fontWeight: 600 }}>
            현재 입찰가
          </div>
          <div style={{ fontSize: 19, fontWeight: 800, color: C.live,
            letterSpacing: '-0.02em', marginTop: 2 }}>
            {item.price.toLocaleString()}<span style={{ fontSize: 13, marginLeft: 2 }}>원</span>
          </div>
        </div>
      </div>
    </div>);
}

function MockBarofarmHome({ empty = false }) {
  const f = FFMOCK_F;
  // 밝은 테마 + 고령층 친화 (높은 대비, 큰 글씨, 큰 터치 영역)
  const C = {
    bg: '#FAFAF5',
    surface: '#FFFFFF',
    surfaceAlt: '#F0F2EA',
    line: '#E2E5D6',
    ink: '#1A1F14',
    inkSoft: '#3D4533',
    inkMute: '#6B7560',
    nh: '#2D8A3E', // NH 그린 (밝은 배경에서 대비 충분)
    nhDeep: '#1F6A2A',
    nhSoft: '#E4F2DC',
    plus: '#E5564A', // + 버튼 강조 (코랄레드)
    live: '#D63031'
  };

  const liveItems = [
  { glyph: 'apple', bg1: '#E5564A', bg2: '#C23E32',
    host: '성주 김영농', hostInitial: '성',
    title: '성주 꿀참외 5kg 박스단위 산지경매',
    viewers: 142, price: 24500 },
  { glyph: 'fish', bg1: '#4A8FBF', bg2: '#2A6B9E',
    host: '완도 청해수산', hostInitial: '완',
    title: '완도 활전복 大 20미 산지직송',
    viewers: 89, price: 78000 },
  { glyph: 'meat', bg1: '#C84B5C', bg2: '#A23445',
    host: '횡성 한우마을', hostInitial: '횡',
    title: '횡성 한우 1++ 등심 1kg',
    viewers: 211, price: 128000 },
  { glyph: 'leaf', bg1: '#4FA84F', bg2: '#3A8A3A',
    host: '평창 산너머', hostInitial: '평',
    title: '평창 고랭지 옥수수 산지경매',
    viewers: 56, price: 18200 }];


  return (
    <div style={{ background: C.bg, minHeight: '100%', paddingBottom: 96,
      color: C.ink, fontFamily: f.body }}>
      {/* ── 헤더 ─────────────────────────────── */}
      <div style={{ background: '#FFFFFF',
        padding: '54px 18px 16px',
        borderBottom: `1px solid ${C.line}`,
        display: 'flex', alignItems: 'center', gap: 12 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ width: 42, height: 42, borderRadius: 12,
            background: `linear-gradient(135deg, ${C.nh} 0%, ${C.nhDeep} 100%)`,
            display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <BFGlyph kind="cart" color="#FFFFFF" size={26} />
          </div>
          <div>
            <div style={{ fontSize: 20, fontWeight: 900, color: C.ink,
              letterSpacing: '-0.02em', lineHeight: 1 }}>NH바로팜</div>
            <div style={{ fontSize: 11, color: C.nh, fontWeight: 700,
              marginTop: 4 }}>산지직송 라이브경매</div>
          </div>
        </div>
        <div style={{ flex: 1 }} />
        {/* 알림 + 설정 — 큰 터치 영역 */}
        <div style={{ display: 'flex', gap: 6 }}>
          <div style={{ width: 44, height: 44, borderRadius: 22,
            background: C.surfaceAlt,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            position: 'relative' }}>
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
              <path d="M6 16V11a6 6 0 1112 0v5l1.5 2H4.5L6 16zM10 20a2 2 0 004 0"
              stroke={C.ink} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
            <span style={{ position: 'absolute', top: 8, right: 9,
              width: 9, height: 9, borderRadius: 5, background: C.live,
              border: '2px solid #fff' }} />
          </div>
          <div style={{ width: 44, height: 44, borderRadius: 22,
            background: C.surfaceAlt,
            display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
              <circle cx="12" cy="12" r="3" stroke={C.ink} strokeWidth="2" />
              <path d="M12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M5 19l2-2M17 7l2-2"
              stroke={C.ink} strokeWidth="2" strokeLinecap="round" />
            </svg>
          </div>
        </div>
      </div>

      {/* ── 카테고리 (원형, 큰 사이즈, LIVE 링) ─────────────── */}
      <div style={{ background: '#FFFFFF', padding: '18px 0 18px',
        borderBottom: `1px solid ${C.line}` }}>
        <div style={{ overflowX: 'auto' }}>
          <div style={{ display: 'flex', gap: 16, padding: '0 18px',
            whiteSpace: 'nowrap' }}>
            {BF_CATS.map((c, i) => {
              const live = i < 3;
              const active = c.id === 'all';
              return (
                <div key={c.id} style={{ display: 'flex', flexDirection: 'column',
                  alignItems: 'center', gap: 8, flexShrink: 0 }}>
                  <div style={{ position: 'relative', fontSize: "9px", width: "64px", height: "64px" }}>
                    {live && <div style={{ position: 'absolute', inset: -3,
                      borderRadius: '50%',
                      border: `2.5px solid ${C.live}` }} />}
                    <div style={{ width: 64, height: 64, borderRadius: 32,
                      background: active ?
                      `linear-gradient(135deg, ${c.hue}, ${c.hue}dd)` :
                      c.hue + '18',
                      border: active ? `3px solid ${C.nh}` : `1px solid ${c.hue}30`,
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      position: 'relative', fontSize: "8px" }}>
                      <BFGlyph kind={c.glyph} color={active ? '#fff' : c.hue} size={36} />
                      {live && <div style={{ position: 'absolute', bottom: -6, left: '50%',
                        transform: 'translateX(-50%)',
                        background: C.live, color: '#fff',
                        fontSize: 9, fontWeight: 800, letterSpacing: '0.04em',
                        padding: '2px 6px', borderRadius: 3,
                        border: '2px solid #fff' }}>LIVE</div>}
                    </div>
                  </div>
                  <div style={{ fontSize: 13, fontWeight: active ? 800 : 600,
                    color: active ? C.ink : C.inkSoft, marginTop: live ? 4 : 0 }}>{c.ko}</div>
                </div>);

            })}
          </div>
        </div>
      </div>

      {/* ── 지금 경매 / 예고 탭 — 큰 글씨 ───────────── */}
      <div style={{ background: '#FFFFFF',
        display: 'flex', gap: 24, padding: '6px 20px 0',
        borderBottom: `1px solid ${C.line}` }}>
        <div style={{ position: 'relative', padding: '14px 0' }}>
          <span style={{ fontSize: 17, fontWeight: 800, color: C.ink,
            letterSpacing: '-0.01em' }}>지금 경매</span>
          <span style={{ marginLeft: 6, fontSize: 13,
            color: C.live, fontWeight: 800 }}>{empty ? 0 : 4}</span>
          <div style={{ position: 'absolute', left: 0, right: 0, bottom: -1,
            height: 3, background: C.nh, borderRadius: 2 }} />
        </div>
        <div style={{ padding: '14px 0', fontSize: 17, fontWeight: 600,
          color: C.inkMute }}>예고 <span style={{ fontSize: 13,
            color: C.inkMute, marginLeft: 4, fontWeight: 700 }}>18</span></div>
      </div>

      {/* ── 콘텐츠 ─────────────────────────────── */}
      {empty ?
      <div style={{ padding: '60px 28px', display: 'flex',
        flexDirection: 'column', alignItems: 'center', textAlign: 'center', gap: 16 }}>
          <div style={{ width: 120, height: 120, borderRadius: 60,
          background: C.nhSoft,
          display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <svg width="64" height="64" viewBox="0 0 56 56" fill="none">
              <rect x="8" y="14" width="40" height="28" rx="4"
            stroke={C.nh} strokeWidth="2.5" />
              <circle cx="28" cy="28" r="7"
            stroke={C.nh} strokeWidth="2.5" />
              <circle cx="28" cy="28" r="2.5" fill={C.nh} />
            </svg>
          </div>
          <div style={{ fontSize: 20, fontWeight: 800, color: C.ink,
          letterSpacing: '-0.01em' }}>
            진행 중인 라이브가 없어요
          </div>
          <div style={{ fontSize: 15, color: C.inkSoft, lineHeight: 1.6 }}>
            우리 농가의 첫 산지경매를 시작해보세요.<br />
            아래 <span style={{ color: C.plus, fontWeight: 800 }}>＋</span> 버튼을 눌러주세요.
          </div>
          <button style={{ marginTop: 12, padding: '16px 28px',
          background: C.nh, color: '#FFFFFF', border: 0,
          borderRadius: 999, fontSize: 16, fontWeight: 800,
          display: 'inline-flex', alignItems: 'center', gap: 8,
          boxShadow: '0 4px 14px rgba(45,138,62,.25)' }}>
            라이브 시작하기 <span>→</span>
          </button>
        </div> :

      <div style={{ padding: '16px 14px', display: 'grid',
        gridTemplateColumns: '1fr 1fr', gap: 12 }}>
          {liveItems.map((it, i) => <BFLiveCard key={i} item={it} C={C} />)}
        </div>
      }

      {/* ── 하단 탭 (5개 + 중앙 + 버튼) ──────────────── */}
      <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0,
        background: '#FFFFFF', borderTop: `1px solid ${C.line}`,
        paddingBottom: 26, paddingTop: 10,
        display: 'flex', alignItems: 'center', justifyContent: 'space-around',
        boxShadow: '0 -2px 12px rgba(0,0,0,.04)' }}>
        <BFTab label="홈" active C={C} glyph={
        <svg width="26" height="26" viewBox="0 0 24 24" fill="none">
            <path d="M3 11l9-7 9 7v9a1 1 0 01-1 1h-5v-7h-6v7H4a1 1 0 01-1-1v-9z"
          fill={C.nh} fillOpacity=".15"
          stroke={C.nh} strokeWidth="2" strokeLinejoin="round" />
          </svg>} color={C.nh} />
        <BFTab label="일반판매" C={C} glyph={
        <svg width="26" height="26" viewBox="0 0 24 24" fill="none">
            <path d="M5 8h14l-1 12a1 1 0 01-1 1H7a1 1 0 01-1-1L5 8z"
          stroke={C.inkSoft} strokeWidth="1.8" strokeLinejoin="round" />
            <path d="M9 8V6a3 3 0 016 0v2"
          stroke={C.inkSoft} strokeWidth="1.8" strokeLinecap="round" />
          </svg>} color={C.inkSoft} />
        {/* + 버튼 — 큰 사이즈 */}
        <div style={{ width: 60, height: 60, borderRadius: 16,
          background: `linear-gradient(135deg, ${C.plus}, #C8453A)`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          boxShadow: '0 8px 22px rgba(229,86,74,.4)',
          marginTop: -12 }}>
          <svg width="30" height="30" viewBox="0 0 24 24" fill="none">
            <path d="M12 5v14M5 12h14" stroke="#fff" strokeWidth="2.6" strokeLinecap="round" />
          </svg>
        </div>
        <BFTab label="채팅" C={C} glyph={
        <svg width="26" height="26" viewBox="0 0 24 24" fill="none">
            <path d="M4 6a2 2 0 012-2h12a2 2 0 012 2v9a2 2 0 01-2 2h-7l-4 4v-4H6a2 2 0 01-2-2V6z"
          stroke={C.inkSoft} strokeWidth="1.8" strokeLinejoin="round" />
          </svg>} color={C.inkSoft} hasDot />
        <BFTab label="내정보" C={C} glyph={
        <svg width="26" height="26" viewBox="0 0 24 24" fill="none">
            <circle cx="12" cy="9" r="3.5" stroke={C.inkSoft} strokeWidth="1.8" />
            <path d="M5 20c1-3.5 4-5.5 7-5.5s6 2 7 5.5"
          stroke={C.inkSoft} strokeWidth="1.8" strokeLinecap="round" />
          </svg>} color={C.inkSoft} />
      </div>
    </div>);
}

// ── 09. 일반판매 (상품 그리드) ─────────────────────────────────────
function MockBarofarmMarket() {
  const f = FFMOCK_F;
  const C = {
    bg:        '#FAFAF5',
    surface:   '#FFFFFF',
    surfaceAlt:'#F0F2EA',
    line:      '#E2E5D6',
    ink:       '#1A1F14',
    inkSoft:   '#3D4533',
    inkMute:   '#6B7560',
    nh:        '#2D8A3E',
    nhDeep:    '#1F6A2A',
    nhSoft:    '#E4F2DC',
    plus:      '#E5564A',
    live:      '#D63031',
  };

  const items = [
    { cat: '과일',  catHue: '#E5564A', bg1: '#FFC4A8', bg2: '#FF8A65',
      glyph: 'apple', seller: '성주김영농', title: '성주 꿀참외 5kg 박스',
      price: 24800, place: '경북 성주', fresh: true },
    { cat: '축산',  catHue: '#C84B5C', bg1: '#FFB0BA', bg2: '#D17085',
      glyph: 'meat',  seller: '횡성한우네', title: '한우 1++ 등심 500g',
      price: 68000, place: '강원 횡성', fresh: false },
    { cat: '채소',  catHue: '#4FA84F', bg1: '#C3E8A8', bg2: '#7BB85A',
      glyph: 'leaf',  seller: '청정고랭지', title: '평창 고랭지 양배추 3통',
      price: 12500, place: '강원 평창', fresh: true },
    { cat: '수산',  catHue: '#4A8FBF', bg1: '#A8D4E8', bg2: '#5B9BC4',
      glyph: 'fish',  seller: '완도청해',   title: '완도 활전복 大 10미',
      price: 39000, place: '전남 완도', fresh: true },
    { cat: '곡물',  catHue: '#D6A84A', bg1: '#F0DBA0', bg2: '#C49C4F',
      glyph: 'grain', seller: '이천쌀집',   title: '이천 햅쌀 10kg (2026)',
      price: 42000, place: '경기 이천', fresh: false },
    { cat: '과일',  catHue: '#E5564A', bg1: '#FFD4B0', bg2: '#FF9F70',
      glyph: 'apple', seller: '제주감귤원', title: '제주 한라봉 5kg',
      price: 28000, place: '제주 서귀포', fresh: true },
  ];

  return (
    <div style={{ background: C.bg, minHeight: '100%', paddingBottom: 96,
      color: C.ink, fontFamily: f.body }}>
      {/* 헤더 */}
      <div style={{ background: '#FFFFFF', padding: '54px 18px 16px',
        borderBottom: `1px solid ${C.line}`,
        display: 'flex', alignItems: 'center', gap: 12 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ width: 42, height: 42, borderRadius: 12,
            background: `linear-gradient(135deg, ${C.nh}, ${C.nhDeep})`,
            display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <BFGlyph kind="cart" color="#FFFFFF" size={26} />
          </div>
          <div>
            <div style={{ fontSize: 20, fontWeight: 900, color: C.ink,
              letterSpacing: '-0.02em', lineHeight: 1 }}>일반 판매</div>
            <div style={{ fontSize: 11, color: C.nh, fontWeight: 700,
              marginTop: 4 }}>산지 직거래 · 정찰가</div>
          </div>
        </div>
        <div style={{ flex: 1 }} />
        <div style={{ width: 44, height: 44, borderRadius: 22,
          background: C.surfaceAlt,
          display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
            <circle cx="11" cy="11" r="6" stroke={C.ink} strokeWidth="2"/>
            <path d="M16 16l4 4" stroke={C.ink} strokeWidth="2" strokeLinecap="round"/>
          </svg>
        </div>
      </div>

      {/* 카테고리 가로 스크롤 (홈과 동일한 패턴, 조금 작게) */}
      <div style={{ background: '#FFFFFF', padding: '14px 0',
        borderBottom: `1px solid ${C.line}` }}>
        <div style={{ overflowX: 'auto' }}>
          <div style={{ display: 'flex', gap: 14, padding: '0 18px',
            whiteSpace: 'nowrap' }}>
            {BF_CATS.map((c) => {
              const active = c.id === 'all';
              return (
                <div key={c.id} style={{ display: 'flex', flexDirection: 'column',
                  alignItems: 'center', gap: 6, flexShrink: 0 }}>
                  <div style={{ width: 56, height: 56, borderRadius: 28,
                    background: active
                      ? `linear-gradient(135deg, ${c.hue}, ${c.hue}dd)`
                      : c.hue + '18',
                    border: active ? `3px solid ${C.nh}` : `1px solid ${c.hue}30`,
                    display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <BFGlyph kind={c.glyph} color={active ? '#fff' : c.hue} size={30} />
                  </div>
                  <div style={{ fontSize: 12, fontWeight: active ? 800 : 600,
                    color: active ? C.ink : C.inkSoft }}>{c.ko}</div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* 정렬 + 필터 바 */}
      <div style={{ background: '#FFFFFF', padding: '12px 18px',
        borderBottom: `1px solid ${C.line}`,
        display: 'flex', alignItems: 'center', gap: 8 }}>
        <div style={{ flex: 1, fontSize: 14, fontWeight: 700, color: C.ink }}>
          전체 <span style={{ color: C.nh, marginLeft: 4 }}>1,284</span>
          <span style={{ color: C.inkMute, fontWeight: 600 }}>건</span>
        </div>
        <div style={{ display: 'inline-flex', alignItems: 'center', gap: 4,
          padding: '8px 14px', background: C.surfaceAlt, borderRadius: 999,
          fontSize: 13, fontWeight: 700, color: C.ink }}>
          최신순
          <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
            <path d="M3 4.5l3 3 3-3" stroke={C.ink} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </div>
        <div style={{ display: 'inline-flex', alignItems: 'center', gap: 4,
          padding: '8px 12px', background: C.surfaceAlt, borderRadius: 999,
          fontSize: 13, fontWeight: 700, color: C.ink }}>
          <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
            <path d="M2 4h10M4 7h6M5.5 10h3" stroke={C.ink} strokeWidth="1.8" strokeLinecap="round"/>
          </svg>
          필터
        </div>
      </div>

      {/* 상품 그리드 */}
      <div style={{ padding: '14px 14px', display: 'grid',
        gridTemplateColumns: '1fr 1fr', gap: 12 }}>
        {items.map((it, i) =>
          <div key={i} style={{ background: '#FFFFFF', borderRadius: 14,
            border: `1px solid ${C.line}`,
            boxShadow: '0 2px 8px rgba(20,30,15,.04)', overflow: 'hidden' }}>
            <div style={{ position: 'relative', aspectRatio: '1/1',
              background: `linear-gradient(135deg, ${it.bg1}, ${it.bg2})` }}>
              <div style={{ position: 'absolute', inset: 0,
                backgroundImage: `repeating-linear-gradient(135deg, rgba(255,255,255,.08), rgba(255,255,255,.08) 8px, rgba(0,0,0,.04) 8px, rgba(0,0,0,.04) 16px)` }} />
              <div style={{ position: 'absolute', right: -16, bottom: -16, opacity: .4 }}>
                <BFGlyph kind={it.glyph} color="#fff" size={140} />
              </div>
              {/* 카테고리 칩 — 좌하단 */}
              <div style={{ position: 'absolute', left: 10, bottom: 10,
                background: 'rgba(0,0,0,.6)', color: '#fff',
                fontSize: 12, fontWeight: 800,
                padding: '5px 12px', borderRadius: 999 }}>
                {it.cat}
              </div>
              {/* 신선 뱃지 */}
              {it.fresh && <div style={{ position: 'absolute', top: 10, right: 10,
                background: C.nh, color: '#fff',
                fontSize: 11, fontWeight: 800,
                padding: '4px 10px', borderRadius: 999 }}>
                새벽수확
              </div>}
            </div>
            <div style={{ padding: '12px 14px 14px' }}>
              <div style={{ fontSize: 12, color: C.inkMute, fontWeight: 600 }}>
                {it.seller} · {it.place}
              </div>
              <div style={{ marginTop: 4, fontSize: 15, fontWeight: 700, color: C.ink,
                lineHeight: 1.35,
                height: 40, overflow: 'hidden',
                display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical' }}>
                {it.title}
              </div>
              <div style={{ marginTop: 8, fontSize: 18, fontWeight: 800, color: C.ink,
                letterSpacing: '-0.02em' }}>
                {it.price.toLocaleString()}<span style={{ fontSize: 13, fontWeight: 700,
                  color: C.inkMute, marginLeft: 2 }}>원</span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* 하단 탭 */}
      <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0,
        background: '#FFFFFF', borderTop: `1px solid ${C.line}`,
        paddingBottom: 26, paddingTop: 10,
        display: 'flex', alignItems: 'center', justifyContent: 'space-around',
        boxShadow: '0 -2px 12px rgba(0,0,0,.04)' }}>
        <BFTab label="홈" C={C} glyph={
          <svg width="26" height="26" viewBox="0 0 24 24" fill="none">
            <path d="M3 11l9-7 9 7v9a1 1 0 01-1 1h-5v-7h-6v7H4a1 1 0 01-1-1v-9z"
              stroke={C.inkSoft} strokeWidth="1.8" strokeLinejoin="round"/>
          </svg>} color={C.inkSoft} />
        <BFTab label="일반판매" active C={C} glyph={
          <svg width="26" height="26" viewBox="0 0 24 24" fill="none">
            <path d="M5 8h14l-1 12a1 1 0 01-1 1H7a1 1 0 01-1-1L5 8z"
              fill={C.nh} fillOpacity=".15"
              stroke={C.nh} strokeWidth="2" strokeLinejoin="round"/>
            <path d="M9 8V6a3 3 0 016 0v2"
              stroke={C.nh} strokeWidth="2" strokeLinecap="round"/>
          </svg>} color={C.nh} />
        <div style={{ width: 60, height: 60, borderRadius: 16,
          background: `linear-gradient(135deg, ${C.plus}, #C8453A)`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          boxShadow: '0 8px 22px rgba(229,86,74,.4)', marginTop: -12 }}>
          <svg width="30" height="30" viewBox="0 0 24 24" fill="none">
            <path d="M12 5v14M5 12h14" stroke="#fff" strokeWidth="2.6" strokeLinecap="round"/>
          </svg>
        </div>
        <BFTab label="채팅" C={C} glyph={
          <svg width="26" height="26" viewBox="0 0 24 24" fill="none">
            <path d="M4 6a2 2 0 012-2h12a2 2 0 012 2v9a2 2 0 01-2 2h-7l-4 4v-4H6a2 2 0 01-2-2V6z"
              stroke={C.inkSoft} strokeWidth="1.8" strokeLinejoin="round"/>
          </svg>} color={C.inkSoft} hasDot />
        <BFTab label="내정보" C={C} glyph={
          <svg width="26" height="26" viewBox="0 0 24 24" fill="none">
            <circle cx="12" cy="9" r="3.5" stroke={C.inkSoft} strokeWidth="1.8"/>
            <path d="M5 20c1-3.5 4-5.5 7-5.5s6 2 7 5.5"
              stroke={C.inkSoft} strokeWidth="1.8" strokeLinecap="round"/>
          </svg>} color={C.inkSoft} />
      </div>
    </div>);
}

function BFTab({ label, glyph, color, active = false, hasDot = false, C }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center',
      gap: 4, position: 'relative' }}>
      <div style={{ position: 'relative' }}>
        {glyph}
        {hasDot && <div style={{ position: 'absolute', top: -1, right: -2,
          width: 9, height: 9, borderRadius: 5, background: '#D63031',
          border: '2px solid #fff' }} />}
      </div>
      <div style={{ fontSize: 12, fontWeight: active ? 800 : 600, color }}>{label}</div>
    </div>);
}

// ── App: lay out all in design canvas with iOS frames ──────────────────
function FFMockupsApp() {
  const sections = [
  { id: 'bf-home', label: '07 · NH바로팜 홈 (와이스 벤치마크)', Comp: MockBarofarmHome, desc: '라이브 그리드 + 카테고리 링' },
  { id: 'bf-empty', label: '08 · NH바로팜 홈 — 빈 상태', Comp: () => <MockBarofarmHome empty />, desc: '진행 중 라이브 0건' },
  { id: 'bf-market', label: '09 · 일반판매', Comp: MockBarofarmMarket, desc: '정찰가 상품 그리드' }];


  return (
    <DesignCanvas>
      <DCSection id="flow" title="Fresh Field — UX Mockups"
      subtitle="개발 핸드오프용 화면. iPhone 14 Pro · 402×874">
        {sections.map(({ id, label, Comp, desc }) =>
        <DCArtboard key={id} id={id} label={label} width={402} height={874}>
            <IOSDevice width={402} height={874} title={undefined}>
              <Comp />
            </IOSDevice>
          </DCArtboard>
        )}
      </DCSection>
    </DesignCanvas>);

}

window.FFMockupsApp = FFMockupsApp;