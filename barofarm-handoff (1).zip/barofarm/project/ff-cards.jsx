// ff-cards.jsx — Fresh Field design system cards (category live auction)

function CardShell({ p, fonts, children, padding = 24, style = {} }) {
  return (
    <div style={{
      width:'100%', height:'100%',
      background: p.bg, color: p.ink,
      fontFamily: fonts.body,
      padding, overflow:'hidden', ...style,
    }}>{children}</div>
  );
}
function Eyebrow({ p, fonts, children }) {
  return (
    <div style={{
      fontFamily: fonts.mono, fontSize:10, letterSpacing:'0.12em',
      textTransform:'uppercase', color: p.inkMute, marginBottom: 12,
    }}>{children}</div>
  );
}
function Title({ p, fonts, sub, children }) {
  return (
    <>
      <div style={{ fontFamily: fonts.display, fontSize:28, fontWeight:700,
        letterSpacing:'-0.02em', color: p.ink, marginBottom: sub ? 6 : 22 }}>
        {children}
      </div>
      {sub && <div style={{ fontSize:13, color: p.inkSoft, marginBottom: 22, lineHeight:1.5 }}>{sub}</div>}
    </>
  );
}

// ─────────────────────────────────────────────────────────────────────
function FFCover({ theme, p, fonts, radius }) {
  return (
    <div style={{
      width:'100%', height:'100%',
      background: p.bg, color: p.ink, fontFamily: fonts.body,
      padding:32, display:'flex', flexDirection:'column', justifyContent:'space-between',
      backgroundImage:`radial-gradient(circle at 80% 15%, ${p.accentSoft}66 0%, transparent 60%),
                      radial-gradient(circle at 10% 90%, ${p.accentSoft}33 0%, transparent 50%)`,
    }}>
      <div>
        <div style={{ fontFamily: fonts.mono, fontSize:11, letterSpacing:'0.12em',
          textTransform:'uppercase', color: p.inkMute }}>
          design system · v2
        </div>
        <div style={{ marginTop: 18, display:'flex', gap:6, alignItems:'center' }}>
          <Sprout color={p.accent} />
          <span style={{ fontFamily: fonts.mono, fontSize:13, color: p.accent, fontWeight: 600 }}>
            FRESH FIELD
          </span>
        </div>
      </div>
      <div>
        <div style={{ fontFamily: fonts.display, fontSize:56, fontWeight:700,
          lineHeight:1.0, letterSpacing:'-0.03em', color: p.ink }}>
          싱그러운<br/>들판
        </div>
        <div style={{ marginTop:14, fontSize:15, color: p.inkSoft, maxWidth: 380, lineHeight:1.6 }}>
          카테고리별 라이브 경매를 위한 디자인 시스템.<br/>
          신선함, 다양성, 그리고 절제.
        </div>
      </div>
      <div style={{ display:'flex', gap:6 }}>
        {CATEGORIES.map(c => (
          <div key={c.id} style={{
            width:48, height:48, borderRadius: radius,
            background: c.hue, color: c.ink,
            display:'flex', alignItems:'center', justifyContent:'center',
            fontSize:18,
          }}>{c.icon}</div>
        ))}
      </div>
    </div>
  );
}

function Sprout({ color }) {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
      <path d="M12 22V12M12 12C12 8 9 6 6 6c0 4 3 6 6 6Zm0 0c0-4 3-6 6-6 0 4-3 6-6 6Z"
        stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  );
}

// ─────────────────────────────────────────────────────────────────────
function Swatch({ name, value, p, fonts, radius, h = 56 }) {
  return (
    <div style={{ display:'flex', flexDirection:'column', gap:6 }}>
      <div style={{ height:h, background:value, borderRadius:radius, border:`1px solid ${p.line}` }}/>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'baseline' }}>
        <div style={{ fontSize:12, fontWeight:600, color:p.ink }}>{name}</div>
        <div style={{ fontFamily:fonts.mono, fontSize:10, color:p.inkMute }}>{String(value).toUpperCase()}</div>
      </div>
    </div>
  );
}

function FFColor({ theme, p, fonts, radius }) {
  const groups = [
    ['Surface', [['Background',p.bg],['Background Alt',p.bgAlt],['Surface',p.surface],['Surface Alt',p.surfaceAlt]]],
    ['Ink',     [['Ink',p.ink],['Ink Soft',p.inkSoft],['Ink Mute',p.inkMute],['Line',p.line]]],
    ['Accent',  [['Accent',p.accent],['Accent Deep',p.accentDeep],['Accent Soft',p.accentSoft]]],
    ['Semantic',[['Live',p.live],['Success',p.success],['Warning',p.warning],['Danger',p.danger]]],
  ];
  return (
    <CardShell p={p} fonts={fonts}>
      <Eyebrow p={p} fonts={fonts}>01 · Color palette</Eyebrow>
      <Title p={p} fonts={fonts}>컬러 팔레트</Title>
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:24, marginBottom: 22 }}>
        {groups.map(([t, items]) => (
          <div key={t}>
            <div style={{ fontFamily:fonts.mono, fontSize:10, letterSpacing:'0.08em',
              textTransform:'uppercase', color:p.inkMute, marginBottom:10 }}>{t}</div>
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10 }}>
              {items.map(([n,v]) => <Swatch key={n} name={n} value={v} p={p} fonts={fonts} radius={radius}/>)}
            </div>
          </div>
        ))}
      </div>
      <Eyebrow p={p} fonts={fonts}>Category accents</Eyebrow>
      <div style={{ display:'grid', gridTemplateColumns:'repeat(6,1fr)', gap:10 }}>
        {CATEGORIES.map(c => (
          <div key={c.id} style={{ display:'flex', flexDirection:'column', gap:6 }}>
            <div style={{ height:56, background:c.hue, borderRadius:radius,
              display:'flex', alignItems:'center', justifyContent:'center',
              color:c.ink, fontSize:20 }}>{c.icon}</div>
            <div style={{ fontSize:11, fontWeight:600, color:p.ink }}>{c.ko}</div>
            <div style={{ fontFamily:fonts.mono, fontSize:9, color:p.inkMute }}>{c.hue.toUpperCase()}</div>
          </div>
        ))}
      </div>
    </CardShell>
  );
}

// ─────────────────────────────────────────────────────────────────────
function FFType({ theme, p, fonts }) {
  const samples = [
    { ...TYPE_SCALE[0], text: '카테고리별 옥션' },
    { ...TYPE_SCALE[2], text: 'Vintage Rolex Submariner 1968' },
    { ...TYPE_SCALE[3], text: '오늘 8시 라이브 · 12개 매물' },
    { ...TYPE_SCALE[5], text: '진품 인증을 마친 빈티지 시계 12점이 라이브 옥션에 올라갑니다. 입찰 시작가는 감정가의 70%부터.' },
    { ...TYPE_SCALE[7], text: '입찰 28회 · 현재가 ₩1,420,000' },
    { ...TYPE_SCALE[8], text: 'LIVE · 02:14 LEFT' },
  ];
  return (
    <CardShell p={p} fonts={fonts}>
      <Eyebrow p={p} fonts={fonts}>02 · Typography</Eyebrow>
      <Title p={p} fonts={fonts} sub={`Display & Body: Pretendard · Mono: JetBrains Mono`}>
        타이포그래피
      </Title>
      <div style={{ display:'flex', flexDirection:'column', gap:18 }}>
        {samples.map((s,i) => (
          <div key={i} style={{ display:'flex', flexDirection:'column', gap:4,
            paddingBottom:16, borderBottom:`1px solid ${p.line}` }}>
            <div style={{ fontFamily:fonts.mono, fontSize:10, color:p.inkMute, letterSpacing:'0.06em' }}>
              {s.name} · {s.size}/{(s.size*s.lh).toFixed(0)} · {s.weight}
            </div>
            <div style={{ fontFamily:fonts.body, fontSize:s.size, fontWeight:s.weight,
              lineHeight:s.lh, letterSpacing:s.tracking, color:p.ink }}>
              {s.text}
            </div>
          </div>
        ))}
      </div>
    </CardShell>
  );
}

// ─────────────────────────────────────────────────────────────────────
function FFSpacing({ p, fonts, radius }) {
  return (
    <CardShell p={p} fonts={fonts}>
      <Eyebrow p={p} fonts={fonts}>03 · Spacing & grid</Eyebrow>
      <Title p={p} fonts={fonts}>스페이싱</Title>
      <div style={{ display:'flex', flexDirection:'column', gap:8, marginBottom: 28 }}>
        {[4,8,12,16,24,32,48].map(v => (
          <div key={v} style={{ display:'flex', alignItems:'center', gap:14 }}>
            <div style={{ width:48, fontFamily:fonts.mono, fontSize:11, color:p.inkMute }}>{v}px</div>
            <div style={{ height:14, width:v*4, background:p.accent, borderRadius:2 }}/>
          </div>
        ))}
      </div>
      <Eyebrow p={p} fonts={fonts}>12-column grid · 16 gutter (web)</Eyebrow>
      <div style={{ display:'grid', gridTemplateColumns:'repeat(12,1fr)', gap:6, height:60, marginTop:8 }}>
        {Array.from({length:12}, (_,i) => (
          <div key={i} style={{ background:p.surfaceAlt, border:`1px dashed ${p.line}`, borderRadius:radius/2,
            display:'flex', alignItems:'center', justifyContent:'center',
            fontFamily:fonts.mono, fontSize:9, color:p.inkMute }}>{i+1}</div>
        ))}
      </div>
      <Eyebrow p={p} fonts={fonts}>Mobile · 4-column</Eyebrow>
      <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:12, height:60, marginTop:8 }}>
        {Array.from({length:4}, (_,i) => (
          <div key={i} style={{ background:p.surfaceAlt, border:`1px dashed ${p.line}`, borderRadius:radius,
            display:'flex', alignItems:'center', justifyContent:'center',
            fontFamily:fonts.mono, fontSize:10, color:p.inkMute }}>col {i+1}</div>
        ))}
      </div>
    </CardShell>
  );
}

// ─────────────────────────────────────────────────────────────────────
function Btn({ kind, p, fonts, radius, children, size='md' }) {
  const padY = size==='lg'?14:size==='sm'?6:10;
  const padX = size==='lg'?22:size==='sm'?12:16;
  const fs   = size==='lg'?16:size==='sm'?12:14;
  const styles = {
    primary:{background:p.accent,color:p.accentInk,border:'none'},
    secondary:{background:p.surface,color:p.ink,border:`1px solid ${p.line}`},
    ghost:{background:'transparent',color:p.ink,border:'none'},
    danger:{background:p.danger,color:'#fff',border:'none'},
    live:{background:p.live,color:'#fff',border:'none'},
  }[kind];
  return (
    <button style={{ ...styles, padding:`${padY}px ${padX}px`, borderRadius:radius,
      fontFamily:fonts.body, fontSize:fs, fontWeight:600, letterSpacing:'-0.01em',
      cursor:'pointer', display:'inline-flex', alignItems:'center', gap:8 }}>
      {children}
    </button>
  );
}

function Pulse({ color }) {
  return (
    <span style={{ position:'relative', width:8, height:8, display:'inline-block' }}>
      <span style={{ position:'absolute', inset:0, borderRadius:'50%', background:color,
        animation:'ff-pulse 1.4s ease-out infinite', opacity:0.6 }}/>
      <span style={{ position:'absolute', inset:0, borderRadius:'50%', background:color }}/>
      <style>{`@keyframes ff-pulse{0%{transform:scale(1);opacity:.6}100%{transform:scale(2.4);opacity:0}}`}</style>
    </span>
  );
}

function Row({ label, p, fonts, children }) {
  return (
    <div>
      <div style={{ fontFamily:fonts.mono, fontSize:10, color:p.inkMute,
        letterSpacing:'0.06em', textTransform:'uppercase', marginBottom:10 }}>{label}</div>
      <div style={{ display:'flex', gap:10, flexWrap:'wrap', alignItems:'center' }}>{children}</div>
    </div>
  );
}

function FFButtons({ p, fonts, radius }) {
  return (
    <CardShell p={p} fonts={fonts}>
      <Eyebrow p={p} fonts={fonts}>04 · Buttons</Eyebrow>
      <Title p={p} fonts={fonts}>버튼</Title>
      <div style={{ display:'flex', flexDirection:'column', gap:22 }}>
        <Row label="Primary" p={p} fonts={fonts}>
          <Btn kind="primary" p={p} fonts={fonts} radius={radius} size="lg">₩1,420,000에 입찰</Btn>
          <Btn kind="primary" p={p} fonts={fonts} radius={radius}>입찰하기</Btn>
          <Btn kind="primary" p={p} fonts={fonts} radius={radius} size="sm">+10,000</Btn>
        </Row>
        <Row label="Secondary" p={p} fonts={fonts}>
          <Btn kind="secondary" p={p} fonts={fonts} radius={radius}>관심상품</Btn>
          <Btn kind="ghost" p={p} fonts={fonts} radius={radius}>나중에</Btn>
        </Row>
        <Row label="Live" p={p} fonts={fonts}>
          <Btn kind="live" p={p} fonts={fonts} radius={radius} size="lg">
            <Pulse color="#fff"/> 라이브 입장
          </Btn>
          <Btn kind="danger" p={p} fonts={fonts} radius={radius}>경매 마감</Btn>
        </Row>
        <Row label="States" p={p} fonts={fonts}>
          <Btn kind="primary" p={p} fonts={fonts} radius={radius}>Default</Btn>
          <button style={{ background:p.accentDeep, color:p.accentInk, border:'none',
            padding:'10px 16px', borderRadius:radius, fontFamily:fonts.body, fontSize:14, fontWeight:600,
            boxShadow:`0 0 0 3px ${p.accent}33` }}>Hover</button>
          <button disabled style={{ background:p.surfaceAlt, color:p.inkMute, border:'none',
            padding:'10px 16px', borderRadius:radius, fontFamily:fonts.body, fontSize:14, fontWeight:600 }}>
            Disabled
          </button>
        </Row>
      </div>
    </CardShell>
  );
}

// ─────────────────────────────────────────────────────────────────────
function FFForm({ p, fonts, radius }) {
  return (
    <CardShell p={p} fonts={fonts}>
      <Eyebrow p={p} fonts={fonts}>05 · Form & input</Eyebrow>
      <Title p={p} fonts={fonts}>폼 & 인풋</Title>
      <div style={{ display:'flex', flexDirection:'column', gap:20 }}>
        <div>
          <div style={{ display:'flex', justifyContent:'space-between', marginBottom:8 }}>
            <div style={{ fontSize:13, fontWeight:600, color:p.ink }}>입찰 금액</div>
            <div style={{ fontSize:11, color:p.inkMute, fontFamily:fonts.mono }}>최소 10,000원 단위</div>
          </div>
          <div style={{ display:'flex', alignItems:'center', gap:8 }}>
            <div style={{ flex:1, display:'flex', alignItems:'center',
              border:`1.5px solid ${p.accent}`, borderRadius:radius,
              background:p.surface, padding:'0 14px', height:48 }}>
              <span style={{ fontSize:14, color:p.inkMute }}>₩</span>
              <input defaultValue="1,420,000" style={{ flex:1, border:'none', outline:'none',
                background:'transparent', color:p.ink, fontFamily:fonts.body,
                fontSize:18, fontWeight:600, marginLeft:8 }}/>
            </div>
            <button style={{ background:p.accent, color:p.accentInk, border:'none',
              padding:'0 18px', height:48, borderRadius:radius,
              fontFamily:fonts.body, fontSize:14, fontWeight:600 }}>입찰</button>
          </div>
        </div>

        <div>
          <div style={{ fontSize:13, fontWeight:600, color:p.ink, marginBottom:8 }}>관심 카테고리</div>
          <div style={{ display:'flex', gap:6, flexWrap:'wrap' }}>
            {CATEGORIES.map((c,i) => {
              const on = i < 3;
              return (
                <div key={c.id} style={{ padding:'7px 12px',
                  background:on?c.hue:p.surface,
                  color:on?c.ink:p.ink,
                  border:on?'none':`1px solid ${p.line}`,
                  borderRadius:999, fontSize:12, fontWeight:500, cursor:'pointer',
                  display:'inline-flex', gap:6, alignItems:'center' }}>
                  <span>{c.icon}</span>{c.ko}
                </div>
              );
            })}
          </div>
        </div>

        <div style={{ display:'flex', gap:12 }}>
          <div style={{ flex:1 }}>
            <div style={{ fontSize:13, fontWeight:600, color:p.ink, marginBottom:8 }}>자동 재입찰</div>
            <Toggle on={true} p={p}/>
          </div>
          <div style={{ flex:1 }}>
            <div style={{ fontSize:13, fontWeight:600, color:p.ink, marginBottom:8 }}>최대 한도</div>
            <input defaultValue="₩2,000,000" style={{ width:'100%', height:40,
              border:`1px solid ${p.line}`, borderRadius:radius, padding:'0 12px',
              background:p.surface, color:p.ink, fontFamily:fonts.body, fontSize:14, outline:'none' }}/>
          </div>
        </div>

        <div>
          <div style={{ fontSize:13, fontWeight:600, color:p.ink, marginBottom:8 }}>에러 상태</div>
          <div style={{ border:`1.5px solid ${p.danger}`, borderRadius:radius,
            background:p.surface, padding:'10px 14px', color:p.ink, fontSize:14 }}>
            ₩1,400,000
          </div>
          <div style={{ marginTop:6, fontSize:12, color:p.danger }}>
            현재가보다 낮습니다. ₩1,420,000 이상 입찰해주세요.
          </div>
        </div>
      </div>
    </CardShell>
  );
}

function Toggle({ on, p }) {
  return (
    <div style={{ width:44, height:26, borderRadius:999, background: on?p.accent:p.line,
      position:'relative', cursor:'pointer', transition:'background .2s' }}>
      <div style={{ position:'absolute', top:3, left: on?21:3, width:20, height:20,
        borderRadius:'50%', background:'#fff', transition:'left .2s',
        boxShadow:'0 1px 3px rgba(0,0,0,.2)' }}/>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────
function FFNav({ p, fonts, radius }) {
  return (
    <CardShell p={p} fonts={fonts}>
      <Eyebrow p={p} fonts={fonts}>06 · Navigation</Eyebrow>
      <Title p={p} fonts={fonts}>내비게이션</Title>

      <Eyebrow p={p} fonts={fonts}>Top nav · web</Eyebrow>
      <div style={{ background:p.surface, borderRadius:radius, border:`1px solid ${p.line}`,
        padding:'14px 20px', display:'flex', alignItems:'center', gap:24, marginBottom:20 }}>
        <div style={{ display:'flex', alignItems:'center', gap:6 }}>
          <Sprout color={p.accent}/>
          <span style={{ fontFamily:fonts.display, fontSize:18, fontWeight:700,
            letterSpacing:'-0.02em', color:p.ink }}>field</span>
        </div>
        <div style={{ display:'flex', gap:18, fontSize:13, color:p.inkSoft, flex:1 }}>
          <div style={{ color:p.accent, fontWeight:600 }}>지금 라이브</div>
          <div>예고 옥션</div>
          <div>카테고리</div>
          <div>구매내역</div>
        </div>
        <div style={{ fontSize:12, color:p.inkMute, fontFamily:fonts.mono }}>@youname</div>
      </div>

      <Eyebrow p={p} fonts={fonts}>Category pills</Eyebrow>
      <div style={{ display:'flex', gap:6, flexWrap:'wrap', marginBottom:20 }}>
        <div style={{ padding:'7px 14px', background:p.ink, color:p.bg, borderRadius:999,
          fontSize:12, fontWeight:600 }}>전체</div>
        {CATEGORIES.map(c => (
          <div key={c.id} style={{ padding:'7px 14px', background:p.surface,
            border:`1px solid ${p.line}`, borderRadius:999,
            fontSize:12, fontWeight:500, color:p.ink,
            display:'inline-flex', alignItems:'center', gap:6 }}>
            <span style={{ color:c.hue }}>{c.icon}</span>{c.ko}
          </div>
        ))}
      </div>

      <Eyebrow p={p} fonts={fonts}>Tab bar · mobile</Eyebrow>
      <div style={{ background:p.surface, borderRadius:radius, border:`1px solid ${p.line}`,
        padding:'10px 14px', display:'flex', justifyContent:'space-around' }}>
        {[
          { label:'홈', icon:'⌂', on:true },
          { label:'라이브', icon:'◉' },
          { label:'관심', icon:'♡' },
          { label:'마이', icon:'○' },
        ].map(it => (
          <div key={it.label} style={{ display:'flex', flexDirection:'column',
            alignItems:'center', gap:3, color: it.on?p.accent:p.inkMute }}>
            <div style={{ fontSize:18, lineHeight:1 }}>{it.icon}</div>
            <div style={{ fontSize:10, fontWeight: it.on?600:400 }}>{it.label}</div>
          </div>
        ))}
      </div>

      <div style={{ marginTop:20, fontSize:12, color:p.inkMute, fontFamily:fonts.mono }}>
        홈 / 패션 / <span style={{ color:p.ink }}>Vintage Rolex Submariner 1968</span>
      </div>
    </CardShell>
  );
}

// ─────────────────────────────────────────────────────────────────────
// Live auction card — featured component
function FFAuction({ p, fonts, radius }) {
  const cat = CATEGORIES[1]; // fashion (vintage watch)
  return (
    <CardShell p={p} fonts={fonts}>
      <Eyebrow p={p} fonts={fonts}>07 · Live auction card</Eyebrow>
      <Title p={p} fonts={fonts}>라이브 옥션 카드</Title>

      <div style={{ background:p.surface, borderRadius:radius*1.5,
        border:`1px solid ${p.line}`, overflow:'hidden' }}>
        <div style={{
          aspectRatio:'4/3',
          background:`repeating-linear-gradient(135deg, ${p.surfaceAlt}, ${p.surfaceAlt} 8px, ${p.bgAlt} 8px, ${p.bgAlt} 16px)`,
          position:'relative', display:'flex', alignItems:'flex-end', padding:14,
        }}>
          <div style={{ position:'absolute', top:14, left:14, display:'flex', gap:6 }}>
            <div style={{ display:'flex', alignItems:'center', gap:6,
              background:p.live, color:'#fff', padding:'5px 10px', borderRadius:4,
              fontFamily:fonts.mono, fontSize:11, fontWeight:600, letterSpacing:'0.08em' }}>
              <Pulse color="#fff"/> LIVE
            </div>
            <div style={{ display:'flex', alignItems:'center', gap:6,
              background:cat.hue, color:cat.ink, padding:'5px 10px', borderRadius:4,
              fontSize:11, fontWeight:600 }}>
              {cat.icon} {cat.ko}
            </div>
          </div>
          <div style={{ position:'absolute', top:14, right:14, background:'rgba(0,0,0,.55)',
            color:'#fff', padding:'5px 10px', borderRadius:4,
            fontFamily:fonts.mono, fontSize:11, fontWeight:500 }}>02:14</div>
          <div style={{ fontFamily:fonts.mono, fontSize:10, color:p.inkMute,
            background:p.bg, padding:'3px 8px', borderRadius:3 }}>product photo</div>
        </div>

        <div style={{ padding:18 }}>
          <div style={{ fontSize:17, fontWeight:600, color:p.ink, letterSpacing:'-0.01em' }}>
            Vintage Rolex Submariner 1968
          </div>
          <div style={{ marginTop:4, fontSize:12, color:p.inkSoft }}>
            진품 인증 · @vintage_seoul · 위탁판매
          </div>

          <div style={{ marginTop:14, display:'flex', alignItems:'baseline', gap:8 }}>
            <div style={{ fontFamily:fonts.display, fontSize:30, fontWeight:700,
              color:p.ink, letterSpacing:'-0.02em', lineHeight:1 }}>1,420,000</div>
            <div style={{ fontSize:14, color:p.inkSoft }}>원</div>
            <div style={{ marginLeft:'auto', fontSize:12, color:p.success, fontWeight:600 }}>
              ↑ +20,000원
            </div>
          </div>
          <div style={{ fontSize:11, color:p.inkMute, fontFamily:fonts.mono, marginTop:4 }}>
            입찰 28회 · 시청 142명
          </div>

          <div style={{ marginTop:16, display:'flex', gap:8 }}>
            <button style={{ flex:1, background:p.accent, color:p.accentInk, border:'none',
              padding:'14px 0', borderRadius:radius,
              fontFamily:fonts.body, fontSize:15, fontWeight:700 }}>
              +10,000원 입찰
            </button>
            <button style={{ background:p.surfaceAlt, color:p.ink, border:`1px solid ${p.line}`,
              padding:'14px 18px', borderRadius:radius, fontSize:14, fontWeight:500 }}>♡</button>
          </div>
        </div>
      </div>
    </CardShell>
  );
}

// ─────────────────────────────────────────────────────────────────────
// Slide-to-bid (kept from original)
function FFSlideBid({ p, fonts, radius, amount='1,420,000', label='밀어서 입찰', height=60, onConfirm }) {
  const [x, setX] = React.useState(0);
  const [confirmed, setConfirmed] = React.useState(false);
  const [dragging, setDragging] = React.useState(false);
  const ref = React.useRef(null);
  const thumbW = height;

  const move = (e) => {
    if (!dragging || !ref.current) return;
    const rect = ref.current.getBoundingClientRect();
    const max = rect.width - thumbW;
    const nx = Math.max(0, Math.min(max, e.clientX - rect.left - thumbW/2));
    setX(nx);
    if (nx >= max - 2) {
      setConfirmed(true); setDragging(false);
      onConfirm?.();
      setTimeout(() => { setConfirmed(false); setX(0); }, 1600);
    }
  };
  const up = () => { setDragging(false); if (!confirmed) setX(0); };
  const w = ref.current?.getBoundingClientRect().width || 1;
  const progress = x / Math.max(1, w - thumbW);
  const fill = confirmed ? p.success : p.accent;

  return (
    <div ref={ref} onPointerMove={move} onPointerUp={up} onPointerCancel={up}
      style={{ position:'relative', width:'100%', height,
        background:p.surfaceAlt, border:`1px solid ${p.line}`, borderRadius:radius,
        overflow:'hidden', userSelect:'none', touchAction:'none' }}>
      <div style={{ position:'absolute', inset:0, background:fill,
        width:`${x+thumbW}px`,
        transition: dragging?'none':'width .25s cubic-bezier(.2,.7,.3,1), background .2s',
        opacity:0.95 }}/>
      <div style={{ position:'absolute', inset:0, display:'flex', alignItems:'center',
        justifyContent:'center', gap:14, fontFamily:fonts.body, fontSize:15, fontWeight:600,
        letterSpacing:'-0.01em', color: progress>0.4?'#fff':p.ink, transition:'color .15s',
        pointerEvents:'none' }}>
        {confirmed
          ? <span style={{ display:'inline-flex', alignItems:'center', gap:8 }}><Check/> 입찰 완료 · ₩{amount}</span>
          : <>
              <span style={{ opacity:1-progress*1.6 }}>{label}</span>
              <span style={{ fontFamily:fonts.mono, fontSize:13, fontWeight:700, opacity:1-progress*1.4 }}>
                ₩{amount}
              </span>
            </>}
      </div>
      {!confirmed && (
        <div style={{ position:'absolute', right:16, top:'50%', transform:'translateY(-50%)',
          color: progress>0.4?'rgba(255,255,255,.7)':p.inkMute, fontSize:18, fontFamily:fonts.mono,
          letterSpacing:'-2px', opacity:1-progress*1.5, pointerEvents:'none' }}>››»</div>
      )}
      <div onPointerDown={(e)=>{ if(!confirmed){ setDragging(true); e.target.setPointerCapture?.(e.pointerId);} }}
        style={{ position:'absolute', top:4, left:4+x, width:thumbW-8, height:height-8,
          borderRadius:Math.max(0, radius-4),
          background: confirmed?p.success:'#fff',
          boxShadow:'0 2px 8px rgba(0,0,0,.22)',
          display:'flex', alignItems:'center', justifyContent:'center',
          cursor: confirmed?'default':'grab',
          transition: dragging?'none':'left .25s cubic-bezier(.2,.7,.3,1), background .2s' }}>
        {confirmed ? <Check color={p.accentInk}/> : <Arrow color={p.accent}/>}
      </div>
    </div>
  );
}

function Arrow({ color }) {
  return (<svg width="20" height="20" viewBox="0 0 20 20" fill="none">
    <path d="M4 10h12M11 5l5 5-5 5" stroke={color} strokeWidth="2.2"
      strokeLinecap="round" strokeLinejoin="round"/></svg>);
}
function Check({ color='#fff' }) {
  return (<svg width="18" height="18" viewBox="0 0 20 20" fill="none">
    <path d="M4 10.5l4 4 8-9" stroke={color} strokeWidth="2.4"
      strokeLinecap="round" strokeLinejoin="round"/></svg>);
}

function FFSlideCard({ p, fonts, radius }) {
  return (
    <CardShell p={p} fonts={fonts}>
      <Eyebrow p={p} fonts={fonts}>08 · Slide to bid</Eyebrow>
      <Title p={p} fonts={fonts} sub="실수 입찰 방지 + 라이브 긴장감. 오른쪽 끝까지 밀어주세요.">
        밀어서 입찰
      </Title>
      <div style={{ display:'flex', flexDirection:'column', gap:24 }}>
        <div>
          <div style={{ fontFamily:fonts.mono, fontSize:10, color:p.inkMute,
            letterSpacing:'0.06em', textTransform:'uppercase', marginBottom:10 }}>Default</div>
          <FFSlideBid p={p} fonts={fonts} radius={radius}/>
        </div>
        <div>
          <div style={{ fontFamily:fonts.mono, fontSize:10, color:p.inkMute,
            letterSpacing:'0.06em', textTransform:'uppercase', marginBottom:10 }}>Compact</div>
          <FFSlideBid p={p} fonts={fonts} radius={radius} height={48} label="밀어서 +10,000원" amount="1,430,000"/>
        </div>
        <div>
          <div style={{ fontFamily:fonts.mono, fontSize:10, color:p.inkMute,
            letterSpacing:'0.06em', textTransform:'uppercase', marginBottom:10 }}>Big · 즉시낙찰</div>
          <FFSlideBid p={p} fonts={fonts} radius={radius} height={72} label="밀어서 즉시낙찰" amount="2,200,000"/>
        </div>
      </div>
    </CardShell>
  );
}

// ─────────────────────────────────────────────────────────────────────
// New: Live chat / bid feed component
function FFLiveFeed({ p, fonts, radius }) {
  const events = [
    { t:'02:14', user:'@kdh_collect', kind:'bid', text:'+10,000원 입찰', amount:'1,420,000' },
    { t:'02:11', user:'@vintage_lover', kind:'chat', text:'시계 무브먼트 보여주세요!' },
    { t:'02:08', user:'@watch_king', kind:'bid', text:'+30,000원 입찰', amount:'1,410,000' },
    { t:'02:05', user:'@_seojin', kind:'chat', text:'박스 풀세트 맞나요?' },
    { t:'02:02', user:'@auctioneer', kind:'host', text:'시작가 ₩1,200,000부터 시작합니다' },
  ];
  return (
    <CardShell p={p} fonts={fonts}>
      <Eyebrow p={p} fonts={fonts}>09 · Live feed</Eyebrow>
      <Title p={p} fonts={fonts} sub="입찰과 채팅이 실시간으로 흐르는 사이드 패널.">
        라이브 피드
      </Title>
      <div style={{ background:p.surface, borderRadius:radius, border:`1px solid ${p.line}`,
        overflow:'hidden' }}>
        <div style={{ padding:'12px 16px', borderBottom:`1px solid ${p.lineSoft}`,
          display:'flex', alignItems:'center', gap:10 }}>
          <Pulse color={p.live}/>
          <div style={{ fontSize:13, fontWeight:600, color:p.ink }}>실시간</div>
          <div style={{ marginLeft:'auto', fontFamily:fonts.mono, fontSize:11, color:p.inkMute }}>
            142 watching
          </div>
        </div>
        <div style={{ display:'flex', flexDirection:'column' }}>
          {events.map((e,i) => (
            <div key={i} style={{
              padding:'12px 16px',
              borderBottom: i<events.length-1?`1px solid ${p.lineSoft}`:'none',
              background: e.kind==='bid'?`${p.accentSoft}55`:'transparent',
              display:'flex', alignItems:'flex-start', gap:10,
            }}>
              <div style={{ fontFamily:fonts.mono, fontSize:10, color:p.inkMute,
                width:36, paddingTop:2 }}>{e.t}</div>
              <div style={{ flex:1 }}>
                <div style={{ display:'flex', alignItems:'baseline', gap:6 }}>
                  <span style={{ fontSize:12, fontWeight:600,
                    color: e.kind==='host'?p.live:e.kind==='bid'?p.accent:p.ink }}>
                    {e.user}
                  </span>
                  {e.kind==='host' && (
                    <span style={{ fontSize:9, padding:'1px 6px', borderRadius:3,
                      background:p.live, color:'#fff', fontFamily:fonts.mono, fontWeight:600 }}>HOST</span>
                  )}
                  {e.kind==='bid' && e.amount && (
                    <span style={{ marginLeft:'auto', fontFamily:fonts.mono, fontSize:11,
                      fontWeight:700, color:p.accentDeep }}>₩{e.amount}</span>
                  )}
                </div>
                <div style={{ marginTop:3, fontSize:13, color:p.ink, lineHeight:1.4 }}>
                  {e.text}
                </div>
              </div>
            </div>
          ))}
        </div>
        <div style={{ padding:10, borderTop:`1px solid ${p.line}`, display:'flex', gap:8 }}>
          <input placeholder="메시지 보내기..." style={{ flex:1, height:36, padding:'0 12px',
            border:`1px solid ${p.line}`, borderRadius:radius,
            background:p.bg, color:p.ink, fontSize:13, outline:'none' }}/>
          <button style={{ background:p.accent, color:p.accentInk, border:'none',
            padding:'0 16px', borderRadius:radius, fontSize:13, fontWeight:600 }}>전송</button>
        </div>
      </div>
    </CardShell>
  );
}

// ─────────────────────────────────────────────────────────────────────
// New: Auction status / lifecycle states
function FFStatus({ p, fonts, radius }) {
  const states = [
    { label:'예고', color:p.inkMute, bg:p.surfaceAlt, desc:'경매 오픈 전, 알림 신청 가능' },
    { label:'라이브', color:'#fff', bg:p.live, pulse:true, desc:'실시간 입찰 진행 중' },
    { label:'입찰 중', color:'#fff', bg:p.accent, desc:'내가 최고가일 때' },
    { label:'경합', color:'#fff', bg:p.warning, desc:'다른 사람이 더 높은 가격' },
    { label:'낙찰', color:'#fff', bg:p.success, desc:'경매 종료 · 결제 대기' },
    { label:'유찰', color:p.ink, bg:p.surfaceMute, desc:'시작가 미달로 종료' },
  ];
  return (
    <CardShell p={p} fonts={fonts}>
      <Eyebrow p={p} fonts={fonts}>10 · Auction states</Eyebrow>
      <Title p={p} fonts={fonts} sub="옥션의 라이프사이클을 표현하는 상태 배지.">
        경매 상태
      </Title>
      <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
        {states.map(s => (
          <div key={s.label} style={{ display:'flex', alignItems:'center', gap:14,
            padding:14, background:p.surface, border:`1px solid ${p.line}`, borderRadius:radius }}>
            <div style={{ display:'inline-flex', alignItems:'center', gap:6,
              padding:'5px 11px', borderRadius:999,
              background:s.bg, color:s.color,
              fontSize:12, fontWeight:600, fontFamily:fonts.body, minWidth:72,
              justifyContent:'center' }}>
              {s.pulse && <Pulse color={s.color}/>}
              {s.label}
            </div>
            <div style={{ fontSize:13, color:p.inkSoft }}>{s.desc}</div>
          </div>
        ))}
      </div>
    </CardShell>
  );
}

// ─────────────────────────────────────────────────────────────────────
// Voice & tone
function FFVoice({ p, fonts, radius }) {
  const voice = {
    title: '담백하고 정확한 말',
    good: [
      '오늘 8시 라이브 · Vintage Watches 12점',
      '입찰 28회 · 현재가 ₩1,420,000',
      '낙찰까지 02:14 남음',
      '판매자가 채팅에 답변 중',
    ],
    avoid: [
      '대박 특가! 놓치면 후회각',
      '꿀템 무조건 사세요',
      '실시간 폭탄세일',
    ],
  };
  return (
    <CardShell p={p} fonts={fonts}>
      <Eyebrow p={p} fonts={fonts}>11 · Voice & tone</Eyebrow>
      <Title p={p} fonts={fonts} sub={voice.title}>보이스 & 톤</Title>

      <div style={{ background:p.surface, border:`1px solid ${p.line}`,
        borderLeft:`3px solid ${p.success}`, borderRadius:radius, padding:18, marginBottom:14 }}>
        <div style={{ fontFamily:fonts.mono, fontSize:10, letterSpacing:'0.08em',
          color:p.success, textTransform:'uppercase', marginBottom:10 }}>✓ 이렇게 써요</div>
        <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
          {voice.good.map((l,i) => (
            <div key={i} style={{ fontSize:14, color:p.ink, lineHeight:1.5 }}>"{l}"</div>
          ))}
        </div>
      </div>

      <div style={{ background:p.surface, border:`1px solid ${p.line}`,
        borderLeft:`3px solid ${p.danger}`, borderRadius:radius, padding:18, marginBottom:18 }}>
        <div style={{ fontFamily:fonts.mono, fontSize:10, letterSpacing:'0.08em',
          color:p.danger, textTransform:'uppercase', marginBottom:10 }}>✕ 피해요</div>
        <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
          {voice.avoid.map((l,i) => (
            <div key={i} style={{ fontSize:13, color:p.inkMute, textDecoration:'line-through' }}>{l}</div>
          ))}
        </div>
      </div>

      <Eyebrow p={p} fonts={fonts}>Principles</Eyebrow>
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10 }}>
        {[
          ['숫자는 정확히', '입찰가, 시간, 카운트'],
          ['재촉하지 않기', '경매에 충분한 시간을'],
          ['카테고리의 언어로', '아트는 아트답게, 패션은 패션답게'],
          ['투명하게', '판매자·인증·이력 공개'],
        ].map(([t,s]) => (
          <div key={t} style={{ padding:12, background:p.surface,
            border:`1px solid ${p.line}`, borderRadius:radius }}>
            <div style={{ fontSize:13, fontWeight:600, color:p.ink }}>{t}</div>
            <div style={{ fontSize:11, color:p.inkMute, marginTop:3 }}>{s}</div>
          </div>
        ))}
      </div>
    </CardShell>
  );
}

Object.assign(window, {
  FFCover, FFColor, FFType, FFSpacing, FFButtons,
  FFForm, FFNav, FFAuction, FFSlideCard, FFLiveFeed, FFStatus, FFVoice,
});
