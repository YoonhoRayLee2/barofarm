// ff-app.jsx — Fresh Field design system app

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "primaryColor": "#5B7A35",
  "radiusOffset": 0,
  "density": "regular",
  "dark": false
}/*EDITMODE-END*/;

function FFApp() {
  const [tw, setTweak] = useTweaks(TWEAK_DEFAULTS);

  const palette = paletteFor(FF, tw.dark);
  if (tw.primaryColor) palette.accent = tw.primaryColor;
  const fonts = FF.fonts;
  const radius = Math.max(0, FF.radius + (tw.radiusOffset * 4));
  const ctx = { theme: FF, p: palette, fonts, radius };

  const W = 460, H = 640, WIDE = 720;

  return (
    <>
      <DesignCanvas>
        <DCSection id="overview" title="Fresh Field · 싱그러운 들판"
          subtitle="카테고리별 라이브 옥션을 위한 디자인 시스템">
          <DCArtboard id="cover" label="00 · Cover" width={W} height={H}>
            <FFCover {...ctx} />
          </DCArtboard>
        </DCSection>

        <DCSection id="foundations" title="Foundations" subtitle="컬러 · 타이포 · 스페이싱">
          <DCArtboard id="color" label="01 · Color" width={WIDE} height={H}>
            <FFColor {...ctx} />
          </DCArtboard>
          <DCArtboard id="type" label="02 · Typography" width={W} height={H}>
            <FFType {...ctx} />
          </DCArtboard>
          <DCArtboard id="spacing" label="03 · Spacing & grid" width={W} height={H}>
            <FFSpacing {...ctx} />
          </DCArtboard>
        </DCSection>

        <DCSection id="components" title="Components" subtitle="버튼 · 폼 · 내비게이션">
          <DCArtboard id="buttons" label="04 · Buttons" width={W} height={H}>
            <FFButtons {...ctx} />
          </DCArtboard>
          <DCArtboard id="form" label="05 · Form & input" width={W} height={H}>
            <FFForm {...ctx} />
          </DCArtboard>
          <DCArtboard id="nav" label="06 · Navigation" width={W} height={H}>
            <FFNav {...ctx} />
          </DCArtboard>
        </DCSection>

        <DCSection id="auction" title="Auction patterns" subtitle="라이브 경매에 특화된 컴포넌트">
          <DCArtboard id="auction-card" label="07 · Live auction card" width={W} height={H}>
            <FFAuction {...ctx} />
          </DCArtboard>
          <DCArtboard id="slide-bid" label="08 · Slide to bid" width={W} height={H}>
            <FFSlideCard {...ctx} />
          </DCArtboard>
          <DCArtboard id="live-feed" label="09 · Live feed" width={W} height={H}>
            <FFLiveFeed {...ctx} />
          </DCArtboard>
          <DCArtboard id="status" label="10 · Auction states" width={W} height={H}>
            <FFStatus {...ctx} />
          </DCArtboard>
        </DCSection>

        <DCSection id="brand" title="Brand & voice" subtitle="언어와 톤">
          <DCArtboard id="voice" label="11 · Voice & tone" width={W} height={H}>
            <FFVoice {...ctx} />
          </DCArtboard>
        </DCSection>
      </DesignCanvas>

      <TweaksPanel>
        <TweakSection label="Theme" />
        <TweakToggle label="Dark mode" value={tw.dark}
          onChange={v => setTweak('dark', v)} />
        <TweakColor label="Accent" value={tw.primaryColor}
          onChange={v => setTweak('primaryColor', v)} />

        <TweakSection label="Shape" />
        <TweakSlider label="Radius offset" value={tw.radiusOffset}
          min={-2} max={4} step={1} unit="·"
          onChange={v => setTweak('radiusOffset', v)} />
        <TweakRadio label="Density" value={tw.density}
          options={['compact', 'regular', 'comfy']}
          onChange={v => setTweak('density', v)} />
      </TweaksPanel>
    </>
  );
}

window.FFApp = FFApp;
