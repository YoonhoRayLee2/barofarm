// fresh-field-themes.jsx
// Fresh Field — refined for category-based live auction commerce.
// Single direction, but with category accents (each category gets its own hue
// derived from the olive base).

const FF = {
  id: 'freshField',
  name: 'Fresh Field',
  ko: '싱그러운 들판',
  tagline: '카테고리별 라이브 옥션 — 들판처럼 다양하게, 풀처럼 신선하게',
  light: {
    bg:        '#F4F2EA',
    bgAlt:     '#EAE7D8',
    surface:   '#FFFFFF',
    surfaceAlt:'#F0EEE2',
    surfaceMute:'#E5E2D2',
    ink:       '#1F2417',
    inkSoft:   '#475040',
    inkMute:   '#7E8675',
    line:      '#DCDCC9',
    lineSoft:  '#E8E5D5',
    accent:    '#5B7A35',
    accentDeep:'#3F5524',
    accentSoft:'#C9D8A8',
    accentInk: '#FFFFFF',
    success:   '#5B7A35',
    warning:   '#B58A2B',
    danger:    '#B23A2C',
    live:      '#D14B33',
  },
  dark: {
    bg:        '#11140D',
    bgAlt:     '#171B12',
    surface:   '#1F2417',
    surfaceAlt:'#272E1D',
    surfaceMute:'#1A1E13',
    ink:       '#EEF0E4',
    inkSoft:   '#B8BFA6',
    inkMute:   '#7E8675',
    line:      '#2E3525',
    lineSoft:  '#222818',
    accent:    '#A8C766',
    accentDeep:'#84A346',
    accentSoft:'#2E3D17',
    accentInk: '#11140D',
    success:   '#A8C766',
    warning:   '#D9B560',
    danger:    '#E47A66',
    live:      '#E47A66',
  },
  fonts: {
    display: "'Pretendard', sans-serif",
    body:    "'Pretendard', -apple-system, system-ui, sans-serif",
    mono:    "'JetBrains Mono', monospace",
  },
  radius: 8,
};

// Categories — each has its own derived accent. Hues stay close to nature palette
// (no rainbow), expressed as olive variants + earthy companions.
// 농산물 카테고리 — 농협 P2C 산지직송 라이브 옥션
const CATEGORIES = [
  { id: 'fruit',     ko: '과일',     en: 'Fruit',     hue: '#C25A2C', ink: '#FFFFFF', icon: '◉' },
  { id: 'veggie',    ko: '채소',     en: 'Vegetable', hue: '#5B7A35', ink: '#FFFFFF', icon: '◆' },
  { id: 'grain',     ko: '곡물·잡곡',en: 'Grain',     hue: '#A8814E', ink: '#FFFFFF', icon: '●' },
  { id: 'meat',      ko: '축산',     en: 'Livestock', hue: '#7E3A2E', ink: '#FFFFFF', icon: '◇' },
  { id: 'sea',       ko: '수산',     en: 'Seafood',   hue: '#3D5A6C', ink: '#FFFFFF', icon: '◐' },
  { id: 'processed', ko: '가공식품', en: 'Processed', hue: '#7E5C2E', ink: '#FFFFFF', icon: '○' },
  { id: 'flower',    ko: '화훼',     en: 'Flower',    hue: '#9C5A6C', ink: '#FFFFFF', icon: '✿' },
  { id: 'specialty', ko: '특산품',   en: 'Specialty', hue: '#446B3A', ink: '#FFFFFF', icon: '★' },
];

const TYPE_SCALE = [
  { name: 'Display L', size: 56, weight: 700, lh: 1.05, tracking: '-0.02em' },
  { name: 'Display M', size: 40, weight: 700, lh: 1.1,  tracking: '-0.02em' },
  { name: 'Heading L', size: 28, weight: 700, lh: 1.2,  tracking: '-0.01em' },
  { name: 'Heading M', size: 22, weight: 600, lh: 1.25, tracking: '-0.01em' },
  { name: 'Heading S', size: 18, weight: 600, lh: 1.3,  tracking: '0' },
  { name: 'Body L',    size: 16, weight: 400, lh: 1.55, tracking: '0' },
  { name: 'Body M',    size: 14, weight: 400, lh: 1.55, tracking: '0' },
  { name: 'Caption',   size: 12, weight: 500, lh: 1.4,  tracking: '0.02em' },
  { name: 'Label',     size: 11, weight: 600, lh: 1.2,  tracking: '0.08em' },
];

function paletteFor(theme, dark, overrides = {}) {
  const base = dark ? theme.dark : theme.light;
  return { ...base, ...overrides };
}

window.FF = FF;
window.CATEGORIES = CATEGORIES;
window.TYPE_SCALE = TYPE_SCALE;
window.paletteFor = paletteFor;
